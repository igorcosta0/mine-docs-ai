<?php
// =========================================
// CONFIG/DATABASE.PHP - Configuração do Banco
// =========================================

class Database
{
    private $host = 'localhost';
    private $port = '3306';
    private $db_name = 'minedocs';
    private $username = 'root';
    private $password = '';
    private $charset = 'utf8mb4';
    private $pdo;
    private static $instance = null;

    // Construtor privado para Singleton
    private function __construct()
    {
        $this->connect();
    }

    // Singleton - uma única instância de conexão
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // Conectar ao banco
    private function connect()
    {
        try {
            $dsn = "mysql:host={$this->host};port={$this->port};dbname={$this->db_name};charset={$this->charset}";

            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES {$this->charset} COLLATE utf8mb4_unicode_ci"
            ];

            $this->pdo = new PDO($dsn, $this->username, $this->password, $options);

            // Log de conexão bem-sucedida
            $this->logConnection('success', 'Conexão estabelecida com sucesso');
        } catch (PDOException $e) {
            // Log de erro
            $this->logConnection('error', $e->getMessage());

            // Em produção, não mostrar detalhes do erro
            if ($_ENV['ENVIRONMENT'] ?? 'development' === 'production') {
                die("Erro de conexão com banco de dados. Contate o administrador.");
            } else {
                die("Erro de conexão: " . $e->getMessage());
            }
        }
    }

    // Obter instância PDO
    public function getPDO()
    {
        return $this->pdo;
    }

    // Testar conexão
    public function testConnection()
    {
        try {
            $stmt = $this->pdo->query("SELECT 1");
            return [
                'success' => true,
                'message' => 'Conexão ativa e funcionando',
                'server_version' => $this->pdo->getAttribute(PDO::ATTR_SERVER_VERSION),
                'database' => $this->db_name
            ];
        } catch (PDOException $e) {
            return [
                'success' => false,
                'message' => 'Erro ao testar conexão: ' . $e->getMessage()
            ];
        }
    }

    // Obter estatísticas do banco
    public function getDatabaseStats()
    {
        try {
            $stats = [];

            // Contar tabelas
            $stmt = $this->pdo->query("
                SELECT COUNT(*) as total_tables 
                FROM information_schema.tables 
                WHERE table_schema = '{$this->db_name}'
            ");
            $stats['total_tables'] = $stmt->fetch()['total_tables'];

            // Contar documentos de referência
            $stmt = $this->pdo->query("SELECT COUNT(*) as total FROM documentos_referencia WHERE status = 'ativo'");
            $stats['documentos_ativos'] = $stmt->fetch()['total'];

            // Contar por tipo de documento
            $stmt = $this->pdo->query("
                SELECT tipo_documento, COUNT(*) as total 
                FROM documentos_referencia 
                WHERE status = 'ativo' 
                GROUP BY tipo_documento
            ");
            $stats['por_tipo'] = $stmt->fetchAll();

            // Último documento inserido
            $stmt = $this->pdo->query("
                SELECT projeto_nome, created_at 
                FROM documentos_referencia 
                ORDER BY created_at DESC 
                LIMIT 1
            ");
            $ultimo = $stmt->fetch();
            $stats['ultimo_documento'] = $ultimo ? $ultimo : null;

            return $stats;
        } catch (PDOException $e) {
            return ['error' => 'Erro ao obter estatísticas: ' . $e->getMessage()];
        }
    }

    // Log de conexões
    private function logConnection($type, $message)
    {
        $logFile = __DIR__ . '/../logs/database.log';
        $logDir = dirname($logFile);

        // Criar diretório de logs se não existir
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }

        $timestamp = date('Y-m-d H:i:s');
        $logEntry = "[$timestamp] [$type] $message" . PHP_EOL;

        file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }

    // Método para executar queries preparadas de forma segura
    public function execute($query, $params = [])
    {
        try {
            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            $this->logConnection('error', "Query error: " . $e->getMessage() . " | Query: " . $query);
            throw new Exception("Erro na execução da query: " . $e->getMessage());
        }
    }

    // Método para buscar um registro
    public function fetchOne($query, $params = [])
    {
        $stmt = $this->execute($query, $params);
        return $stmt->fetch();
    }

    // Método para buscar múltiplos registros
    public function fetchAll($query, $params = [])
    {
        $stmt = $this->execute($query, $params);
        return $stmt->fetchAll();
    }

    // Método para inserir e retornar ID
    public function insert($query, $params = [])
    {
        $stmt = $this->execute($query, $params);
        return $this->pdo->lastInsertId();
    }

    // Método para contar registros
    public function count($table, $conditions = [], $params = [])
    {
        $whereClause = '';
        if (!empty($conditions)) {
            $whereClause = ' WHERE ' . implode(' AND ', $conditions);
        }

        $query = "SELECT COUNT(*) as total FROM {$table}{$whereClause}";
        $result = $this->fetchOne($query, $params);

        return $result['total'] ?? 0;
    }

    // Método para verificar se registro existe
    public function exists($table, $conditions, $params)
    {
        return $this->count($table, $conditions, $params) > 0;
    }

    // Iniciar transação
    public function beginTransaction()
    {
        return $this->pdo->beginTransaction();
    }

    // Confirmar transação
    public function commit()
    {
        return $this->pdo->commit();
    }

    // Cancelar transação
    public function rollback()
    {
        return $this->pdo->rollback();
    }

    // Limpar logs antigos (manter apenas 30 dias)
    public function cleanOldLogs()
    {
        $logFile = __DIR__ . '/../logs/database.log';

        if (file_exists($logFile) && filesize($logFile) > 10 * 1024 * 1024) { // 10MB
            $lines = file($logFile);
            $cutoff = date('Y-m-d H:i:s', strtotime('-30 days'));
            $newLines = [];

            foreach ($lines as $line) {
                if (preg_match('/^\[([^\]]+)\]/', $line, $matches)) {
                    if ($matches[1] >= $cutoff) {
                        $newLines[] = $line;
                    }
                }
            }

            file_put_contents($logFile, implode('', $newLines));
        }
    }

    // Impedir clonagem
    private function __clone() {}

    // Impedir deserialização
    public function __wakeup()
    {
        throw new Exception("Cannot unserialize singleton");
    }
}

// =========================================
// FUNÇÕES DE CONVENIÊNCIA GLOBAIS
// =========================================

/**
 * Obter instância do banco de dados
 */
function db()
{
    return Database::getInstance();
}

/**
 * Executar query de forma rápida
 */
function dbQuery($query, $params = [])
{
    return db()->execute($query, $params);
}

/**
 * Buscar um registro
 */
function dbFetchOne($query, $params = [])
{
    return db()->fetchOne($query, $params);
}

/**
 * Buscar múltiplos registros
 */
function dbFetchAll($query, $params = [])
{
    return db()->fetchAll($query, $params);
}

/**
 * Inserir registro e retornar ID
 */
function dbInsert($query, $params = [])
{
    return db()->insert($query, $params);
}

/**
 * Testar se conexão está funcionando
 */
function testDatabaseConnection()
{
    return db()->testConnection();
}

// =========================================
// CONFIGURAÇÕES ADICIONAIS
// =========================================

// Definir timezone
date_default_timezone_set('America/Sao_Paulo');

// Configurações de erro PHP
if (($_ENV['ENVIRONMENT'] ?? 'development') === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Auto-limpeza de logs (executar 1x por dia)
$lastCleanup = __DIR__ . '/../logs/last_cleanup.txt';
if (!file_exists($lastCleanup) || filemtime($lastCleanup) < strtotime('-1 day')) {
    Database::getInstance()->cleanOldLogs();
    touch($lastCleanup);
}
