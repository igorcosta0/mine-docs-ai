<?php
// =========================================
// DEBUG_MEMORIAL.PHP - Teste de Diagnóstico
// =========================================

// Capturar todos os erros
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>🔍 Diagnóstico do Sistema MineDocs</h2>";

// 1. Testar includes
echo "<h3>1. Testando Includes</h3>";
try {
    if (file_exists('config/database.php')) {
        echo "✅ config/database.php existe<br>";
        require_once 'config/database.php';
        echo "✅ config/database.php carregado<br>";
    } else {
        echo "❌ config/database.php NÃO EXISTE<br>";
        echo "Caminho atual: " . __DIR__ . "<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro ao carregar database.php: " . $e->getMessage() . "<br>";
}

try {
    if (file_exists('classes/MemorialDescritivo.php')) {
        echo "✅ classes/MemorialDescritivo.php existe<br>";
        require_once 'classes/MemorialDescritivo.php';
        echo "✅ classes/MemorialDescritivo.php carregado<br>";
    } else {
        echo "❌ classes/MemorialDescritivo.php NÃO EXISTE<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro ao carregar MemorialDescritivo.php: " . $e->getMessage() . "<br>";
}

// 2. Testar conexão
echo "<h3>2. Testando Conexão com Banco</h3>";
try {
    $connectionTest = testDatabaseConnection();
    
    if ($connectionTest['success']) {
        echo "✅ Conexão com banco: OK<br>";
        echo "Database: " . $connectionTest['database'] . "<br>";
    } else {
        echo "❌ Conexão com banco: ERRO<br>";
        echo "Erro: " . $connectionTest['message'] . "<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro na conexão: " . $e->getMessage() . "<br>";
}

// 3. Testar classe MemorialDescritivo
echo "<h3>3. Testando Classe MemorialDescritivo</h3>";
try {
    $memorial = new MemorialDescritivo();
    echo "✅ Classe MemorialDescritivo instanciada<br>";
    
    $template = $memorial->obterTemplate();
    if ($template) {
        echo "✅ Template encontrado: " . $template['nome_template'] . "<br>";
    } else {
        echo "⚠️ Template não encontrado<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro na classe MemorialDescritivo: " . $e->getMessage() . "<br>";
}

// 4. Simular requisição POST
echo "<h3>4. Simulando Requisição POST</h3>";

$dadosExemplo = [
    'projeto_nome' => 'Teste Debug',
    'cliente' => 'Vale S.A.',
    'localizacao' => 'Itabira, MG',
    'categoria_projeto' => 'lavra',
    'tipo_mineracao' => 'ferro',
    'porte_projeto' => 'medio',
    'complexidade' => 'media'
];

echo "Dados de exemplo:<br>";
echo "<pre>" . json_encode($dadosExemplo, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";

// 5. Testar JSON
echo "<h3>5. Testando JSON</h3>";
try {
    $jsonTest = json_encode($dadosExemplo);
    if ($jsonTest === false) {
        echo "❌ Erro ao gerar JSON: " . json_last_error_msg() . "<br>";
    } else {
        echo "✅ JSON gerado com sucesso<br>";
    }
    
    $decodedTest = json_decode($jsonTest, true);
    if ($decodedTest === null) {
        echo "❌ Erro ao decodificar JSON: " . json_last_error_msg() . "<br>";
    } else {
        echo "✅ JSON decodificado com sucesso<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro com JSON: " . $e->getMessage() . "<br>";
}

// 6. Testar headers (simular)
echo "<h3>6. Informações do Servidor</h3>";
echo "PHP Version: " . phpversion() . "<br>";
echo "Server Software: " . ($_SERVER['SERVER_SOFTWARE'] ?? 'N/A') . "<br>";
echo "Document Root: " . ($_SERVER['DOCUMENT_ROOT'] ?? 'N/A') . "<br>";
echo "Script Name: " . ($_SERVER['SCRIPT_NAME'] ?? 'N/A') . "<br>";

// 7. Verificar extensões necessárias
echo "<h3>7. Extensões PHP</h3>";
$extensoes = ['pdo', 'pdo_mysql', 'json', 'mbstring'];
foreach ($extensoes as $ext) {
    if (extension_loaded($ext)) {
        echo "✅ $ext carregada<br>";
    } else {
        echo "❌ $ext NÃO carregada<br>";
    }
}

// 8. Teste manual do processamento
echo "<h3>8. Teste Manual do Processamento</h3>";

try {
    // Simular o que o processar_memorial.php faz
    echo "Iniciando teste manual...<br>";
    
    if (class_exists('MemorialDescritivo')) {
        $memorial = new MemorialDescritivo();
        
        // Testar busca de similares
        $criterios = [
            'categoria_projeto' => 'lavra',
            'tipo_mineracao' => 'ferro',
            'porte_projeto' => 'medio',
            'complexidade' => 'media'
        ];
        
        $similares = $memorial->buscarDocumentosSimilares($criterios, 3);
        echo "Busca de similares: " . ($similares['success'] ? 'OK' : 'ERRO') . "<br>";
        
        if (!$similares['success']) {
            echo "Erro na busca: " . $similares['error'] . "<br>";
        }
        
        // Teste completo seria muito longo, mas já dá para ver onde está o problema
        echo "✅ Processamento manual funcionando<br>";
        
    } else {
        echo "❌ Classe MemorialDescritivo não encontrada<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Erro no teste manual: " . $e->getMessage() . "<br>";
    echo "Stack trace: <br><pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<hr>";
echo "<h3>🎯 RESUMO</h3>";
echo "<p>Se você viu erros acima, corrija-os primeiro antes de testar o processar_memorial.php</p>";
echo "<p>Se tudo está ✅, o problema pode estar nos headers HTTP ou na estrutura de pastas.</p>";

// 9. Verificar estrutura de pastas
echo "<h3>9. Estrutura de Pastas</h3>";
$estrutura = [
    'config' => 'config/',
    'classes' => 'classes/',
    'logs' => 'logs/',
    'js' => 'js/',
    'modals' => 'modals/'
];

foreach ($estrutura as $nome => $pasta) {
    if (is_dir($pasta)) {
        echo "✅ Pasta $nome existe<br>";
        $arquivos = scandir($pasta);
        $arquivos = array_diff($arquivos, ['.', '..']);
        if (!empty($arquivos)) {
            echo "&nbsp;&nbsp;Arquivos: " . implode(', ', $arquivos) . "<br>";
        }
    } else {
        echo "❌ Pasta $nome NÃO existe<br>";
    }
}
?>