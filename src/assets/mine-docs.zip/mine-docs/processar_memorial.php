<?php
// =========================================
// PROCESSAR_MEMORIAL.PHP - Backend Principal
// =========================================

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Tratar OPTIONS (CORS preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Verificar método
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método não permitido']);
    exit;
}

require_once 'config/database.php';
require_once 'classes/MemorialDescritivo.php';

try {

    // =========================================
    // 1. RECEBER E VALIDAR DADOS
    // =========================================

    $input = file_get_contents('php://input');
    $dados = json_decode($input, true);

    if (!$dados) {
        throw new Exception('Dados JSON inválidos');
    }

    // Log da requisição
    logProcessamento('info', 'Iniciando processamento', $dados);

    // Validar campos obrigatórios
    $camposObrigatorios = [
        'projeto_nome',
        'cliente',
        'localizacao',
        'categoria_projeto',
        'tipo_mineracao',
        'porte_projeto',
        'complexidade'
    ];

    foreach ($camposObrigatorios as $campo) {
        if (empty($dados[$campo])) {
            throw new Exception("Campo obrigatório faltando: {$campo}");
        }
    }

    // =========================================
    // 2. INICIALIZAR CLASSES
    // =========================================

    $memorial = new MemorialDescritivo();
    $templatememorial = $memorial->obterTemplate();

    if (!$templatememorial) {
        throw new Exception('Template não encontrado no banco de dados');
    }

    // =========================================
    // 3. BUSCAR DOCUMENTOS SIMILARES
    // =========================================

    logProcessamento('info', 'Buscando documentos similares');

    $criterios = [
        'categoria_projeto' => $dados['categoria_projeto'],
        'tipo_mineracao' => $dados['tipo_mineracao'],
        'porte_projeto' => $dados['porte_projeto'],
        'complexidade' => $dados['complexidade']
    ];

    $documentosSimilares = $memorial->buscarDocumentosSimilares($criterios, 5);

    if (!$documentosSimilares['success']) {
        logProcessamento('warning', 'Nenhum documento similar encontrado');
        $documentosSimilares['documentos'] = [];
    }

    // =========================================
    // 4. PREPARAR CONTEXTO PARA IA
    // =========================================

    logProcessamento('info', 'Preparando contexto para IA');

    $contextoIA = prepararContextoIA($dados, $documentosSimilares['documentos'], $templateMemorial);

    // =========================================
    // 5. GERAR SEÇÕES DO MEMORIAL
    // =========================================

    logProcessamento('info', 'Gerando seções do memorial');

    $secoes = [];
    $secoesObrigatorias = $templateMemorial['secoes_obrigatorias'];

    foreach ($secoesObrigatorias as $nomeSecao) {
        logProcessamento('info', "Gerando seção: {$nomeSecao}");

        $secaoGerada = gerarSecao($nomeSecao, $contextoIA, $templateMemorial);
        $secoes[$nomeSecao] = $secaoGerada;

        // Simular delay de processamento
        usleep(500000); // 0.5 segundos
    }

    // =========================================
    // 6. MONTAR DOCUMENTO FINAL
    // =========================================

    logProcessamento('info', 'Montando documento final');

    $documentoFinal = montarDocumentoFinal($dados, $secoes, $templateMemorial);

    // =========================================
    // 7. SALVAR NO HISTÓRICO
    // =========================================

    $documentoHash = gerarHashDocumento($documentoFinal);
    $referenciaUtilizadas = array_column($documentosSimilares['documentos'], 'id');

    salvarHistorico([
        'documento_hash' => $documentoHash,
        'tipo_documento' => 'memorial_descritivo',
        'dados_projeto' => $dados,
        'referencias_utilizadas' => $referenciaUtilizadas,
        'documento_gerado' => $documentoFinal,
        'tempo_geracao' => time() - $_SERVER['REQUEST_TIME'],
        'qualidade_estimada' => 4.2 // Simular qualidade estimada
    ]);

    // =========================================
    // 8. INCREMENTAR USO DOS DOCUMENTOS REFERÊNCIA
    // =========================================

    foreach ($referenciaUtilizadas as $docId) {
        $memorial->incrementarUso($docId);
    }

    // =========================================
    // 9. RESPOSTA FINAL
    // =========================================

    logProcessamento('success', 'Memorial descritivo gerado com sucesso', [
        'documento_hash' => $documentoHash,
        'secoes_geradas' => count($secoes),
        'referencias_utilizadas' => count($referenciaUtilizadas)
    ]);

    $resposta = [
        'success' => true,
        'message' => 'Memorial descritivo gerado com sucesso!',
        'data' => [
            'documento_hash' => $documentoHash,
            'projeto_nome' => $dados['projeto_nome'],
            'cliente' => $dados['cliente'],
            'secoes_geradas' => array_keys($secoes),
            'documento_completo' => $documentoFinal,
            'referencias_utilizadas' => count($referenciaUtilizadas),
            'tempo_processamento' => time() - $_SERVER['REQUEST_TIME'] . ' segundos',
            'qualidade_estimada' => 4.2,
            'download_url' => "download_memorial.php?hash={$documentoHash}"
        ],
        'estatisticas' => [
            'total_secoes' => count($secoes),
            'palavras_total' => contarPalavras($documentoFinal),
            'caracteres_total' => strlen($documentoFinal)
        ]
    ];

    echo json_encode($resposta, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} catch (Exception $e) {

    logProcessamento('error', 'Erro no processamento', [
        'error' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);

    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'details' => [
            'file' => basename($e->getFile()),
            'line' => $e->getLine(),
            'timestamp' => date('Y-m-d H:i:s')
        ]
    ], JSON_UNESCAPED_UNICODE);
}

// =========================================
// FUNÇÕES AUXILIARES
// =========================================

/**
 * Preparar contexto completo para IA
 */
function prepararContextoIA($dadosProjeto, $documentosSimilares, $template)
{

    $contexto = [
        'projeto' => $dadosProjeto,
        'template' => $template,
        'referencias' => []
    ];

    // Organizar referências por seção
    foreach ($documentosSimilares as $doc) {
        if (isset($doc['secoes'])) {
            foreach ($doc['secoes'] as $nomeSecao => $conteudoSecao) {
                if (!isset($contexto['referencias'][$nomeSecao])) {
                    $contexto['referencias'][$nomeSecao] = [];
                }

                $contexto['referencias'][$nomeSecao][] = [
                    'projeto' => $doc['projeto_nome'],
                    'cliente' => $doc['cliente'],
                    'conteudo' => $conteudoSecao['conteudo'],
                    'qualidade' => $doc['qualidade_avaliacao'] ?? 3.0
                ];
            }
        }
    }

    return $contexto;
}

/**
 * Gerar uma seção específica do memorial
 */
function gerarSecao($nomeSecao, $contextoIA, $template)
{

    // Obter prompt específico da seção
    $promptTemplate = $template['prompts_ia'][$nomeSecao] ?? '';

    if (empty($promptTemplate)) {
        throw new Exception("Prompt não encontrado para seção: {$nomeSecao}");
    }

    // Substituir variáveis no prompt
    $prompt = substituirVariaveis($promptTemplate, $contextoIA);

    // Obter referências específicas da seção
    $referencias = $contextoIA['referencias'][$nomeSecao] ?? [];

    // AQUI SERIA A CHAMADA PARA IA REAL
    // Por enquanto, vamos simular a geração
    $conteudoGerado = simularGeracaoIA($nomeSecao, $contextoIA['projeto'], $referencias);

    return [
        'nome' => $nomeSecao,
        'conteudo' => $conteudoGerado,
        'prompt_utilizado' => $prompt,
        'referencias_count' => count($referencias),
        'palavras_chave' => extrairPalavrasChaveSecao($conteudoGerado),
        'qualidade_estimada' => rand(38, 50) / 10 // 3.8 a 5.0
    ];
}

/**
 * Simular geração de IA (substituir por IA real)
 */
function simularGeracaoIA($nomeSecao, $dadosProjeto, $referencias)
{

    $templates = [
        'objetivo' => "Este memorial descritivo tem por finalidade apresentar os procedimentos técnicos e metodológicos para o projeto {projeto_nome}, desenvolvido para {cliente}, localizado em {localizacao}. O projeto caracteriza-se como uma operação de {categoria_projeto} de {tipo_mineracao}, classificado como porte {porte_projeto} com complexidade {complexidade}. O objetivo principal é estabelecer as diretrizes técnicas necessárias para a execução segura e eficiente das atividades previstas, em conformidade com as normas técnicas e regulamentações ambientais vigentes.",

        'contextualizacao' => "O projeto {projeto_nome} está inserido no contexto da mineração brasileira de {tipo_mineracao}, região reconhecida por suas reservas minerais de qualidade. A localização em {localizacao} oferece vantagens logísticas significativas para o desenvolvimento das atividades de {categoria_projeto}. O empreendimento visa atender à crescente demanda por {tipo_mineracao}, contribuindo para o desenvolvimento econômico regional e nacional. A classificação como projeto de porte {porte_projeto} reflete o planejamento estratégico adequado aos recursos disponíveis e aos objetivos propostos.",

        'localizacao' => "O projeto {projeto_nome} localiza-se em {localizacao}, região com coordenadas geográficas estratégicas para operações de mineração. O acesso ao local é facilitado por vias principais, permitindo o transporte eficiente de equipamentos e materiais. A infraestrutura regional disponível inclui energia elétrica, telecomunicações e recursos hídricos adequados às necessidades operacionais. A proximidade com centros urbanos garante disponibilidade de mão de obra qualificada e serviços de apoio essenciais para as operações de {categoria_projeto}.",

        'caracteristicas_tecnicas' => "As características técnicas do projeto {projeto_nome} incluem operações especializadas de {categoria_projeto} para {tipo_mineracao}. A área total do projeto abrange {area_hectares} hectares, dimensionada conforme estudos geológicos e de viabilidade técnica. O investimento estimado de R$ {investimento_estimado} reflete a infraestrutura necessária para operações de porte {porte_projeto}. Os equipamentos principais incluem tecnologia adequada para mineração de {tipo_mineracao}, com capacidade produtiva dimensionada conforme complexidade {complexidade}.",

        'metodologia' => "A metodologia proposta para o projeto {projeto_nome} baseia-se em técnicas consolidadas de {categoria_projeto} aplicadas à mineração de {tipo_mineracao}. Os procedimentos operacionais seguem sequência lógica de atividades, iniciando com preparação da área, seguida pelas operações principais e finalização com recuperação ambiental. Os controles de qualidade implementados garantem conformidade com especificações técnicas e normas ambientais. O monitoramento contínuo das atividades permite ajustes operacionais conforme necessário, assegurando eficiência e segurança.",

        'conclusoes' => "O memorial descritivo do projeto {projeto_nome} demonstra viabilidade técnica e conformidade com normas vigentes. As especificações apresentadas asseguram execução segura das operações de {categoria_projeto} para {tipo_mineracao}. O projeto contribuirá significativamente para o desenvolvimento econômico da região de {localizacao}, gerando empregos e agregando valor à cadeia produtiva mineral. Recomenda-se proceder com as etapas subsequentes conforme cronograma estabelecido, mantendo supervisão técnica especializada durante toda execução."
    ];

    $template = $templates[$nomeSecao] ?? "Conteúdo da seção {$nomeSecao} para o projeto {projeto_nome}.";

    // Substituir variáveis
    $conteudo = str_replace([
        '{projeto_nome}',
        '{cliente}',
        '{localizacao}',
        '{categoria_projeto}',
        '{tipo_mineracao}',
        '{porte_projeto}',
        '{complexidade}',
        '{area_hectares}',
        '{investimento_estimado}'
    ], [
        $dadosProjeto['projeto_nome'],
        $dadosProjeto['cliente'],
        $dadosProjeto['localizacao'],
        $dadosProjeto['categoria_projeto'],
        $dadosProjeto['tipo_mineracao'],
        $dadosProjeto['porte_projeto'],
        $dadosProjeto['complexidade'],
        $dadosProjeto['area_hectares'] ?? 'não especificada',
        number_format($dadosProjeto['investimento_estimado'] ?? 0, 2, ',', '.')
    ], $template);

    // Adicionar variações baseadas nas referências
    if (!empty($referencias)) {
        $conteudo .= " Este projeto considera as melhores práticas identificadas em " .
            count($referencias) . " projetos similares anteriores.";
    }

    return $conteudo;
}

/**
 * Substituir variáveis no template
 */
function substituirVariaveis($template, $contexto)
{
    $variaveis = [
        '{projeto_nome}' => $contexto['projeto']['projeto_nome'],
        '{cliente}' => $contexto['projeto']['cliente'],
        '{localizacao}' => $contexto['projeto']['localizacao'],
        '{categoria_projeto}' => $contexto['projeto']['categoria_projeto'],
        '{tipo_mineracao}' => $contexto['projeto']['tipo_mineracao'],
        '{porte_projeto}' => $contexto['projeto']['porte_projeto'],
        '{complexidade}' => $contexto['projeto']['complexidade']
    ];

    return str_replace(array_keys($variaveis), array_values($variaveis), $template);
}

/**
 * Montar documento final
 */
function montarDocumentoFinal($dados, $secoes, $template)
{

    $documento = "# MEMORIAL DESCRITIVO\n\n";
    $documento .= "**Projeto:** " . $dados['projeto_nome'] . "\n";
    $documento .= "**Cliente:** " . $dados['cliente'] . "\n";
    $documento .= "**Localização:** " . $dados['localizacao'] . "\n";
    $documento .= "**Data:** " . date('d/m/Y') . "\n\n";

    $documento .= "---\n\n";

    $ordem = 1;
    foreach ($secoes as $secao) {
        $documento .= "## {$ordem}. " . strtoupper($secao['nome']) . "\n\n";
        $documento .= $secao['conteudo'] . "\n\n";
        $ordem++;
    }

    $documento .= "---\n\n";
    $documento .= "**Documento gerado automaticamente pelo sistema MineDocs**\n";
    $documento .= "**Data/Hora:** " . date('d/m/Y H:i:s') . "\n";

    return $documento;
}

/**
 * Extrair palavras-chave de uma seção
 */
function extrairPalavrasChaveSecao($conteudo)
{
    $memorial = new MemorialDescritivo();
    return $memorial->extrairPalavrasChave($conteudo, 5);
}

/**
 * Gerar hash único para o documento
 */
function gerarHashDocumento($conteudo)
{
    return 'MD_' . date('Ymd_His') . '_' . substr(md5($conteudo), 0, 8);
}

/**
 * Contar palavras no documento
 */
function contarPalavras($texto)
{
    return str_word_count(strip_tags($texto));
}

/**
 * Salvar no histórico de gerações
 */
function salvarHistorico($dados)
{
    try {
        $query = "
            INSERT INTO historico_geracoes (
                documento_hash, tipo_documento, dados_projeto, 
                referencias_utilizadas, documento_gerado, 
                tempo_geracao_segundos, qualidade_estimada
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ";

        $params = [
            $dados['documento_hash'],
            $dados['tipo_documento'],
            json_encode($dados['dados_projeto']),
            json_encode($dados['referencias_utilizadas']),
            $dados['documento_gerado'],
            $dados['tempo_geracao'],
            $dados['qualidade_estimada']
        ];

        db()->execute($query, $params);
    } catch (Exception $e) {
        logProcessamento('error', 'Erro ao salvar histórico: ' . $e->getMessage());
    }
}

/**
 * Log do processamento
 */
function logProcessamento($level, $message, $context = [])
{
    $logFile = __DIR__ . '/logs/processamento.log';
    $logDir = dirname($logFile);

    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }

    $timestamp = date('Y-m-d H:i:s');
    $contextStr = !empty($context) ? ' | ' . json_encode($context, JSON_UNESCAPED_UNICODE) : '';
    $logEntry = "[$timestamp] [$level] $message$contextStr" . PHP_EOL;

    file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
}
