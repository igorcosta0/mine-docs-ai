<!-- Modal Bootstrap Fullscreen -->
<div class="modal modal-fullscreen fade" id="developer-modal" tabindex="-1" aria-labelledby="documentModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header border-bottom">
                <h4 class="modal-title fw-bold text-primary" id="documentModalLabel">
                    <i class="bi bi-code me-3"></i>
                </h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body d-flex align-items-center justify-content-center bg-light">
                <div class="development-message">
                    <div class="dev-icon">
                        <i class="bi bi-code"></i>
                    </div>
                    <h3 class="text-primary mb-3">Em Desenvolvimento</h3>
                    <p class="text-muted mb-3">
                        Esta funcionalidade está sendo desenvolvida pela nossa equipe técnica.
                    </p>
                    <p class="text-muted mb-4">
                        Em breve você poderá criar e gerenciar documentos de forma completa.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>