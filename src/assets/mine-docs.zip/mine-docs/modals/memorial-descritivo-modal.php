<!-- ========================================= -->
<!-- MEMORIAL DESCRITIVO - MODAL FORMULÁRIO -->
<!-- ========================================= -->

<div class="modal modal-fullscreen fade" id="memorial-descritivo" tabindex="-1"
    aria-labelledby="memorialDescritivoLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Header -->
            <div class="modal-header border-bottom">
                <h4 class="modal-title fw-bold text-primary" id="memorialDescritivoLabel">
                    <i class="bi bi-book me-3"></i>Memorial Descritivo
                </h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!-- Body -->
            <div class="modal-body bg-light">
                <div class="container-fluid py-4">
                    <div class="row justify-content-center">
                        <div class="col-xl-8 col-lg-10">

                            <!-- Header do Formulário -->
                            <div class="text-center mb-5">
                                <div class="dev-icon mx-auto mb-3">
                                    <i class="bi bi-book"></i>
                                </div>
                                <h3 class="text-primary mb-2">Geração de Memorial Descritivo</h3>
                                <p class="text-muted">
                                    Preencha os dados do projeto para gerar automaticamente o memorial descritivo
                                </p>
                            </div>

                            <!-- Formulário -->
                            <form id="memorialDescritivoForm" class="needs-validation" novalidate>

                                <!-- Seção 1: Identificação do Projeto -->
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <h5 class="mb-0">
                                            <i class="bi bi-info-circle me-2"></i>Identificação do Projeto
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="projeto_nome" class="form-label">
                                                        Nome do Projeto <span class="text-danger">*</span>
                                                    </label>
                                                    <input type="text" class="form-control" id="projeto_nome"
                                                        name="projeto_nome" required
                                                        placeholder="Ex: Expansão Mina São José">
                                                    <div class="invalid-feedback">
                                                        Por favor, informe o nome do projeto.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="cliente" class="form-label">
                                                        Cliente <span class="text-danger">*</span>
                                                    </label>
                                                    <input type="text" class="form-control" id="cliente"
                                                        name="cliente" required
                                                        placeholder="Ex: Vale S.A.">
                                                    <div class="invalid-feedback">
                                                        Por favor, informe o cliente.
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="localizacao" class="form-label">
                                                        Localização <span class="text-danger">*</span>
                                                    </label>
                                                    <input type="text" class="form-control" id="localizacao"
                                                        name="localizacao" required
                                                        placeholder="Ex: Itabira, Minas Gerais, Brasil">
                                                    <div class="invalid-feedback">
                                                        Por favor, informe a localização.
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Seção 2: Classificação do Projeto -->
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <h5 class="mb-0">
                                            <i class="bi bi-diagram-3 me-2"></i>Classificação do Projeto
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="categoria_projeto" class="form-label">
                                                        Categoria do Projeto <span class="text-danger">*</span>
                                                    </label>
                                                    <select class="form-select" id="categoria_projeto"
                                                        name="categoria_projeto" required>
                                                        <option value="">Selecione a categoria</option>
                                                        <option value="lavra">Lavra</option>
                                                        <option value="beneficiamento">Beneficiamento</option>
                                                        <option value="infraestrutura">Infraestrutura</option>
                                                        <option value="ambiental">Ambiental</option>
                                                        <option value="pesquisa">Pesquisa</option>
                                                    </select>
                                                    <div class="invalid-feedback">
                                                        Por favor, selecione a categoria do projeto.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="tipo_mineracao" class="form-label">
                                                        Tipo de Mineração <span class="text-danger">*</span>
                                                    </label>
                                                    <select class="form-select" id="tipo_mineracao"
                                                        name="tipo_mineracao" required>
                                                        <option value="">Selecione o tipo</option>
                                                        <option value="ferro">Ferro</option>
                                                        <option value="ouro">Ouro</option>
                                                        <option value="cobre">Cobre</option>
                                                        <option value="bauxita">Bauxita</option>
                                                        <option value="manganes">Manganês</option>
                                                        <option value="niquel">Níquel</option>
                                                        <option value="fosfato">Fosfato</option>
                                                        <option value="outros">Outros</option>
                                                    </select>
                                                    <div class="invalid-feedback">
                                                        Por favor, selecione o tipo de mineração.
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="porte_projeto" class="form-label">
                                                        Porte do Projeto <span class="text-danger">*</span>
                                                    </label>
                                                    <select class="form-select" id="porte_projeto"
                                                        name="porte_projeto" required>
                                                        <option value="">Selecione o porte</option>
                                                        <option value="pequeno">Pequeno</option>
                                                        <option value="medio">Médio</option>
                                                        <option value="grande">Grande</option>
                                                    </select>
                                                    <div class="invalid-feedback">
                                                        Por favor, selecione o porte do projeto.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="complexidade" class="form-label">
                                                        Complexidade <span class="text-danger">*</span>
                                                    </label>
                                                    <select class="form-select" id="complexidade"
                                                        name="complexidade" required>
                                                        <option value="">Selecione a complexidade</option>
                                                        <option value="baixa">Baixa</option>
                                                        <option value="media" selected>Média</option>
                                                        <option value="alta">Alta</option>
                                                    </select>
                                                    <div class="invalid-feedback">
                                                        Por favor, selecione a complexidade.
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Seção 3: Dados Técnicos -->
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <h5 class="mb-0">
                                            <i class="bi bi-gear-fill me-2"></i>Dados Técnicos
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="area_hectares" class="form-label">
                                                        Área (hectares)
                                                    </label>
                                                    <input type="number" class="form-control" id="area_hectares"
                                                        name="area_hectares" step="0.01" min="0"
                                                        placeholder="Ex: 150.75">
                                                    <small class="form-text text-muted">
                                                        Área total do projeto em hectares
                                                    </small>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="investimento_estimado" class="form-label">
                                                        Investimento Estimado (R$)
                                                    </label>
                                                    <input type="number" class="form-control" id="investimento_estimado"
                                                        name="investimento_estimado" step="0.01" min="0"
                                                        placeholder="Ex: 50000000">
                                                    <small class="form-text text-muted">
                                                        Investimento total estimado em reais
                                                    </small>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="duracao_meses" class="form-label">
                                                        Duração (meses)
                                                    </label>
                                                    <input type="number" class="form-control" id="duracao_meses"
                                                        name="duracao_meses" min="1"
                                                        placeholder="Ex: 24">
                                                    <small class="form-text text-muted">
                                                        Duração prevista do projeto
                                                    </small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Seção 4: Responsável Técnico -->
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <h5 class="mb-0">
                                            <i class="bi bi-person-badge me-2"></i>Responsável Técnico
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="engenheiro_responsavel" class="form-label">
                                                        Engenheiro Responsável
                                                    </label>
                                                    <input type="text" class="form-control" id="engenheiro_responsavel"
                                                        name="engenheiro_responsavel"
                                                        placeholder="Ex: João Silva - CREA 123456">
                                                    <small class="form-text text-muted">
                                                        Nome completo e registro profissional
                                                    </small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Botões de Ação -->
                                <div class="text-center">
                                    <button type="button" class="btn btn-secondary me-3" data-bs-dismiss="modal">
                                        <i class="bi bi-x-circle me-2"></i>Cancelar
                                    </button>
                                    <!-- <button type="submit" class="btn btn-custom-primary" id="btnGerarDocumento">
                                        <i class="bi bi-magic me-2"></i>Gerar Memorial Descritivo
                                    </button> -->

                                    <button type="button" class="btn btn-custom-primary" id="btnGerarDocumento" onclick="
                                        const form = document.getElementById('memorialDescritivoForm');
                                        if (!form.checkValidity()) {
                                            form.classList.add('was-validated');
                                            return;
                                        }
                                        
                                        // Loading
                                        if (typeof ProfessionalLoading !== 'undefined') {
                                            ProfessionalLoading.show({
                                                title: 'Gerando Memorial',
                                                infoText: 'Processando...',
                                                stages: [
                                                    { icon: 'bi-search', text: 'Analisando...', duration: 600 },
                                                    { icon: 'bi-file-earmark-text', text: 'Gerando...', duration: 600 },
                                                    { icon: 'bi-check-circle', text: 'Concluído!', duration: 400 }
                                                ]
                                            });
                                        }
                                        
                                        // Download após 1.6 segundos
                                        setTimeout(() => {
                                            if (typeof ProfessionalLoading !== 'undefined') ProfessionalLoading.hide();
                                            
                                            const modal = bootstrap.Modal.getInstance(document.getElementById('memorial-descritivo'));
                                            if (modal) modal.hide();
                                            
                                            window.location.href = 'gerar_memorial_demo.php';
                                            
                                            setTimeout(() => {
                                                if (typeof showToast !== 'undefined') {
                                                    showToast('success', 'Sucesso!', 'Download iniciado!');
                                                }
                                            }, 500);
                                        }, 1600);
                                    ">
                                        <i class="bi bi-magic me-2"></i>Gerar Memorial Descritivo
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript do Modal -->
<script>
    // =========================================
    // MEMORIAL DESCRITIVO - INTEGRAÇÃO COM BACKEND
    // =========================================

    class MemorialDescritivoModal {
        constructor() {
            this.form = document.getElementById('memorialDescritivoForm');
            this.modal = document.getElementById('memorial-descritivo');
            this.btnGerar = document.getElementById('btnGerarDocumento');

            this.init();
        }

        init() {
            this.setupEventListeners();
            this.setupValidation();
            this.setupMasks();
        }

        setupEventListeners() {
            // Submit do formulário
            this.form.addEventListener('submit', (e) => this.handleSubmit(e));

            // Reset ao fechar modal
            this.modal.addEventListener('hidden.bs.modal', () => this.resetForm());
        }

        setupValidation() {
            // Bootstrap validation
            this.form.addEventListener('submit', function(event) {
                if (!this.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                this.classList.add('was-validated');
            });
        }

        setupMasks() {
            // Máscara para valores monetários
            const investimentoInput = document.getElementById('investimento_estimado');
            if (investimentoInput) {
                investimentoInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    if (value) {
                        // Formatar como decimal
                        value = (parseInt(value) / 100).toFixed(2);
                        e.target.value = value;
                    }
                });
            }

            // Máscara para área (permitir decimais)
            const areaInput = document.getElementById('area_hectares');
            if (areaInput) {
                areaInput.addEventListener('input', function(e) {
                    // Permitir apenas números e ponto decimal
                    this.value = this.value.replace(/[^0-9.]/g, '');

                    // Permitir apenas um ponto decimal
                    const parts = this.value.split('.');
                    if (parts.length > 2) {
                        this.value = parts[0] + '.' + parts.slice(1).join('');
                    }
                });
            }
        }

        handleSubmit(event) {
            event.preventDefault();
            event.stopPropagation();

            if (!this.form.checkValidity()) {
                return;
            }

            // Coletar dados do formulário
            const formData = this.collectFormData();

            // Configurar loading específico do Memorial Descritivo
            const loadingConfig = {
                title: 'Gerando Memorial Descritivo',
                infoText: 'Analisando projetos similares com IA',
                stages: [{
                        icon: 'bi-search',
                        text: 'Analisando projetos similares...',
                        duration: 2000
                    },
                    {
                        icon: 'bi-robot',
                        text: 'Aplicando inteligência artificial...',
                        duration: 2500
                    },
                    {
                        icon: 'bi-file-earmark-text',
                        text: 'Gerando seções do documento...',
                        duration: 2000
                    },
                    {
                        icon: 'bi-check-circle',
                        text: 'Finalizando memorial descritivo...',
                        duration: 1500
                    }
                ]
            };

            // Desabilitar botão
            this.btnGerar.disabled = true;

            // Mostrar loading profissional
            ProfessionalLoading.show(loadingConfig);

            // Processar dados com backend real
            this.processMemorialDescritivo(formData);
        }

        collectFormData() {
            const formData = new FormData(this.form);
            const dados = {};

            // Converter FormData para objeto
            for (let [key, value] of formData.entries()) {
                dados[key] = value;
            }

            // Processar campos específicos
            if (dados.area_hectares) {
                dados.area_hectares = parseFloat(dados.area_hectares);
            }

            if (dados.investimento_estimado) {
                dados.investimento_estimado = parseFloat(dados.investimento_estimado);
            }

            if (dados.duracao_meses) {
                dados.duracao_meses = parseInt(dados.duracao_meses);
            }

            return dados;
        }

        processMemorialDescritivo(dados) {
            // Chamada AJAX real para o backend
            fetch('processar_memorial.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(dados)
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                    }
                    return response.json();
                })
                .then(result => {
                    this.handleSuccess(result);
                })
                .catch(error => {
                    this.handleError(error);
                });
        }

        handleSuccess(result) {
            // Esconder loading
            ProfessionalLoading.hide();

            // Reabilitar botão
            this.btnGerar.disabled = false;

            if (result.success) {
                // Mostrar resultado de sucesso
                this.showSuccessModal(result);
            } else {
                // Tratar erro do servidor
                this.handleError(new Error(result.error || 'Erro desconhecido'));
            }
        }

        showSuccessModal(result) {
            const data = result.data;
            const estatisticas = result.estatisticas;

            // Criar modal de sucesso
            const successModal = `
            <div class="modal fade" id="successModal" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header bg-success text-white">
                            <h5 class="modal-title">
                                <i class="bi bi-check-circle me-2"></i>Memorial Descritivo Gerado!
                            </h5>
                            <button type="button" class="btn-close btn-close-white" 
                                    data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6 class="text-primary">📋 Informações do Projeto</h6>
                                    <p><strong>Projeto:</strong> ${data.projeto_nome}</p>
                                    <p><strong>Cliente:</strong> ${data.cliente}</p>
                                    <p><strong>Hash:</strong> <code>${data.documento_hash}</code></p>
                                </div>
                                <div class="col-md-6">
                                    <h6 class="text-primary">📊 Estatísticas</h6>
                                    <p><strong>Seções:</strong> ${estatisticas.total_secoes}</p>
                                    <p><strong>Palavras:</strong> ${estatisticas.palavras_total}</p>
                                    <p><strong>Qualidade:</strong> ⭐ ${data.qualidade_estimada}/5.0</p>
                                </div>
                            </div>
                            
                            <div class="mt-3">
                                <h6 class="text-primary">📑 Seções Geradas</h6>
                                <div class="row">
                                    ${data.secoes_geradas.map(secao => 
                                        `<div class="col-md-4">
                                            <span class="badge bg-secondary">${secao}</span>
                                        </div>`
                                    ).join('')}
                                </div>
                            </div>
                            
                            <div class="mt-3">
                                <h6 class="text-primary">🚀 Processamento</h6>
                                <p><strong>Tempo:</strong> ${data.tempo_processamento}</p>
                                <p><strong>Referências:</strong> ${data.referencias_utilizadas} documentos similares</p>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                Fechar
                            </button>
                            <button type="button" class="btn btn-primary" onclick="downloadMemorial('${data.documento_hash}')">
                                <i class="bi bi-download me-2"></i>Download PDF
                            </button>
                            <button type="button" class="btn btn-info" onclick="visualizarMemorial('${data.documento_hash}')">
                                <i class="bi bi-eye me-2"></i>Visualizar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

            // Remover modal anterior se existir
            const existingModal = document.getElementById('successModal');
            if (existingModal) {
                existingModal.remove();
            }

            // Adicionar novo modal
            document.body.insertAdjacentHTML('beforeend', successModal);

            // Mostrar modal
            const modalInstance = new bootstrap.Modal(document.getElementById('successModal'));
            modalInstance.show();

            // Fechar modal principal
            const mainModalInstance = bootstrap.Modal.getInstance(this.modal);
            if (mainModalInstance) {
                mainModalInstance.hide();
            }

            // Reset form
            this.resetForm();
        }

        handleError(error) {
            // Esconder loading
            ProfessionalLoading.hide();

            // Reabilitar botão
            this.btnGerar.disabled = false;

            // Mostrar modal de erro
            const errorModal = `
            <div class="modal fade" id="errorModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-danger text-white">
                            <h5 class="modal-title">
                                <i class="bi bi-exclamation-triangle me-2"></i>Erro no Processamento
                            </h5>
                            <button type="button" class="btn-close btn-close-white" 
                                    data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="alert alert-danger" role="alert">
                                <h6 class="alert-heading">Ops! Algo deu errado</h6>
                                <p class="mb-0">${error.message}</p>
                            </div>
                            
                            <h6 class="mt-3">💡 Possíveis soluções:</h6>
                            <ul>
                                <li>Verifique sua conexão com a internet</li>
                                <li>Tente novamente em alguns segundos</li>
                                <li>Verifique se todos os campos estão preenchidos corretamente</li>
                                <li>Se o problema persistir, contate o administrador</li>
                            </ul>
                            
                            <div class="mt-3">
                                <small class="text-muted">
                                    <i class="bi bi-clock me-1"></i>
                                    Erro ocorrido em: ${new Date().toLocaleString()}
                                </small>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                Fechar
                            </button>
                            <button type="button" class="btn btn-primary" onclick="location.reload()">
                                <i class="bi bi-arrow-clockwise me-2"></i>Recarregar Página
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

            // Remover modal anterior se existir
            const existingErrorModal = document.getElementById('errorModal');
            if (existingErrorModal) {
                existingErrorModal.remove();
            }

            // Adicionar modal de erro
            document.body.insertAdjacentHTML('beforeend', errorModal);

            // Mostrar modal
            const modalInstance = new bootstrap.Modal(document.getElementById('errorModal'));
            modalInstance.show();

            // Log do erro
            console.error('Erro no processamento do Memorial:', error);
        }

        resetForm() {
            // Reset form
            this.form.reset();
            this.form.classList.remove('was-validated');

            // Reset botão
            this.btnGerar.disabled = false;

            // Limpar campos específicos
            const complexidadeSelect = document.getElementById('complexidade');
            if (complexidadeSelect) {
                complexidadeSelect.value = 'media'; // Valor padrão
            }
        }

        // Método público para abrir modal
        open() {
            const modalInstance = new bootstrap.Modal(this.modal);
            modalInstance.show();
        }

        // Método público para fechar modal
        close() {
            const modalInstance = bootstrap.Modal.getInstance(this.modal);
            if (modalInstance) {
                modalInstance.hide();
            }
        }

        // Método para preencher dados (útil para edição)
        fillData(dados) {
            Object.keys(dados).forEach(key => {
                const element = this.form.elements[key];
                if (element) {
                    element.value = dados[key];
                }
            });
        }

        // Método para validar formulário programaticamente
        validate() {
            return this.form.checkValidity();
        }

        // Método para obter dados sem processar
        getData() {
            return this.collectFormData();
        }
    }

    // =========================================
    // FUNÇÕES GLOBAIS DE UTILIDADE
    // =========================================

    /**
     * Download do memorial em PDF
     */
    function downloadMemorial(documentoHash) {
        // Criar link temporário para download
        const link = document.createElement('a');
        link.href = `download_memorial.php?hash=${documentoHash}&format=pdf`;
        link.download = `Memorial_${documentoHash}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        // Feedback visual
        showToast('success', 'Download iniciado!', 'O arquivo PDF será baixado em instantes.');
    }

    /**
     * Visualizar memorial
     */
    function visualizarMemorial(documentoHash) {
        // Abrir em nova janela/aba
        const url = `visualizar_memorial.php?hash=${documentoHash}`;
        window.open(url, '_blank');

        // Feedback visual
        showToast('info', 'Abrindo visualização...', 'O documento será aberto em nova aba.');
    }

    /**
     * Compartilhar memorial
     */
    function compartilharMemorial(documentoHash) {
        const url = `${window.location.origin}/visualizar_memorial.php?hash=${documentoHash}`;

        if (navigator.share) {
            // API nativa de compartilhamento (mobile)
            navigator.share({
                title: 'Memorial Descritivo - MineDocs',
                url: url
            });
        } else {
            // Copiar para clipboard
            navigator.clipboard.writeText(url).then(() => {
                showToast('success', 'Link copiado!', 'O link foi copiado para sua área de transferência.');
            });
        }
    }

    /**
     * Mostrar toast notification
     */
    function showToast(type, title, message) {
        const toastId = 'toast_' + Date.now();
        const bgClass = type === 'success' ? 'bg-success' :
            type === 'error' ? 'bg-danger' :
            type === 'warning' ? 'bg-warning' : 'bg-info';

        const toastHtml = `
        <div class="toast align-items-center text-white ${bgClass} border-0" 
             id="${toastId}" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    <strong>${title}</strong><br>
                    <small>${message}</small>
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" 
                        data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    `;

        // Container de toasts
        let toastContainer = document.getElementById('toastContainer');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toastContainer';
            toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            toastContainer.style.zIndex = '9999';
            document.body.appendChild(toastContainer);
        }

        toastContainer.insertAdjacentHTML('beforeend', toastHtml);

        const toastElement = document.getElementById(toastId);
        const toast = new bootstrap.Toast(toastElement, {
            autohide: true,
            delay: 5000
        });

        toast.show();

        // Remover elemento após esconder
        toastElement.addEventListener('hidden.bs.toast', () => {
            toastElement.remove();
        });
    }

    /**
     * Avaliar qualidade do documento gerado
     */
    function avaliarMemorial(documentoHash, nota, feedback = '') {
        fetch('avaliar_memorial.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    documento_hash: documentoHash,
                    nota: nota,
                    feedback: feedback
                })
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    showToast('success', 'Avaliação enviada!', 'Obrigado pelo seu feedback.');
                } else {
                    showToast('error', 'Erro', 'Não foi possível enviar a avaliação.');
                }
            })
            .catch(error => {
                showToast('error', 'Erro', 'Erro de conexão ao enviar avaliação.');
            });
    }

    // =========================================
    // INICIALIZAÇÃO
    // =========================================

    // Inicializar quando DOM estiver pronto
    document.addEventListener('DOMContentLoaded', function() {
        // Verificar se ProfessionalLoading está disponível
        if (typeof ProfessionalLoading === 'undefined') {
            console.warn('ProfessionalLoading não encontrado. Inclua o componente de loading.');
        }

        // Criar instância global
        window.memorialDescritivoModal = new MemorialDescritivoModal();
    });

    // Métodos de conveniência globais
    window.openMemorialDescritivo = function() {
        if (window.memorialDescritivoModal) {
            window.memorialDescritivoModal.open();
        }
    };

    window.closeMemorialDescritivo = function() {
        if (window.memorialDescritivoModal) {
            window.memorialDescritivoModal.close();
        }
    };

    // =========================================
    // HANDLERS DE EVENTOS GLOBAIS
    // =========================================

    // Tratar erros globais AJAX
    window.addEventListener('unhandledrejection', function(event) {
        console.error('Erro não tratado:', event.reason);

        if (event.reason.message && event.reason.message.includes('memorial')) {
            showToast('error', 'Erro no Sistema', 'Ocorreu um erro inesperado. Tente novamente.');
        }
    });

    // Debug: log de todas as interações (apenas em desenvolvimento)
    if (window.location.hostname === 'localhost') {
        document.addEventListener('click', function(e) {
            if (e.target.closest('#memorialDescritivoForm')) {
                console.log('Interação no formulário:', e.target);
            }
        });
    }
</script>