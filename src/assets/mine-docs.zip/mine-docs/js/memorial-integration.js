// =========================================
// MEMORIAL DESCRITIVO - INTEGRAÇÃO COM BACKEND
// memorial-integration.js
// =========================================

class MemorialDescritivoModal {
    constructor() {
        this.form = document.getElementById('memorialDescritivoForm');
        this.modal = document.getElementById('memorial-descritivo');
        this.btnGerar = document.getElementById('btnGerarDocumento');

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupValidation();
        this.setupMasks();
    }

    setupEventListeners() {
        // Submit do formulário
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));

        // Reset ao fechar modal
        this.modal.addEventListener('hidden.bs.modal', () => this.resetForm());
    }

    setupValidation() {
        // Bootstrap validation
        this.form.addEventListener('submit', function (event) {
            if (!this.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            this.classList.add('was-validated');
        });
    }

    setupMasks() {
        // Máscara para valores monetários
        const investimentoInput = document.getElementById('investimento_estimado');
        if (investimentoInput) {
            investimentoInput.addEventListener('input', function (e) {
                let value = e.target.value.replace(/\D/g, '');
                if (value) {
                    // Formatar como decimal
                    value = (parseInt(value) / 100).toFixed(2);
                    e.target.value = value;
                }
            });
        }

        // Máscara para área (permitir decimais)
        const areaInput = document.getElementById('area_hectares');
        if (areaInput) {
            areaInput.addEventListener('input', function (e) {
                // Permitir apenas números e ponto decimal
                this.value = this.value.replace(/[^0-9.]/g, '');

                // Permitir apenas um ponto decimal
                const parts = this.value.split('.');
                if (parts.length > 2) {
                    this.value = parts[0] + '.' + parts.slice(1).join('');
                }
            });
        }
    }

    handleSubmit(event) {
        event.preventDefault();
        event.stopPropagation();

        if (!this.form.checkValidity()) {
            return;
        }

        // Coletar dados do formulário
        const formData = this.collectFormData();

        // Configurar loading específico do Memorial Descritivo
        const loadingConfig = {
            title: 'Gerando Memorial Descritivo',
            infoText: 'Analisando projetos similares com IA',
            stages: [
                {
                    icon: 'bi-search',
                    text: 'Analisando projetos similares...',
                    duration: 2000
                },
                {
                    icon: 'bi-robot',
                    text: 'Aplicando inteligência artificial...',
                    duration: 2500
                },
                {
                    icon: 'bi-file-earmark-text',
                    text: 'Gerando seções do documento...',
                    duration: 2000
                },
                {
                    icon: 'bi-check-circle',
                    text: 'Finalizando memorial descritivo...',
                    duration: 1500
                }
            ]
        };

        // Desabilitar botão
        this.btnGerar.disabled = true;

        // Mostrar loading profissional
        if (typeof ProfessionalLoading !== 'undefined') {
            ProfessionalLoading.show(loadingConfig);
        } else {
            console.warn('ProfessionalLoading não encontrado');
        }

        // Processar dados com backend real
        this.processMemorialDescritivo(formData);
    }

    collectFormData() {
        const formData = new FormData(this.form);
        const dados = {};

        // Converter FormData para objeto
        for (let [key, value] of formData.entries()) {
            dados[key] = value;
        }

        // Processar campos específicos
        if (dados.area_hectares) {
            dados.area_hectares = parseFloat(dados.area_hectares);
        }

        if (dados.investimento_estimado) {
            dados.investimento_estimado = parseFloat(dados.investimento_estimado);
        }

        if (dados.duracao_meses) {
            dados.duracao_meses = parseInt(dados.duracao_meses);
        }

        return dados;
    }

    processMemorialDescritivo(dados) {
        // Log dos dados que serão enviados
        console.log('Enviando dados para backend:', dados);

        // Chamada AJAX real para o backend
        fetch('processar_memorial.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(dados)
        })
            .then(response => {
                console.log('Status da resposta:', response.status);
                console.log('Headers da resposta:', response.headers);

                // Verificar se a resposta é JSON válido
                const contentType = response.headers.get('content-type');
                if (!contentType || !contentType.includes('application/json')) {
                    throw new Error('Resposta não é JSON válido. Tipo: ' + (contentType || 'desconhecido'));
                }

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }

                return response.text().then(text => {
                    console.log('Texto da resposta:', text);
                    try {
                        return JSON.parse(text);
                    } catch (e) {
                        throw new Error('Erro ao parsear JSON: ' + e.message + '\nResposta: ' + text.substring(0, 200));
                    }
                });
            })
            .then(result => {
                console.log('Resultado do backend:', result);
                this.handleSuccess(result);
            })
            .catch(error => {
                console.error('Erro na requisição:', error);
                this.handleError(error);
            });
    }

    handleSuccess(result) {
        // Esconder loading
        if (typeof ProfessionalLoading !== 'undefined') {
            ProfessionalLoading.hide();
        }

        // Reabilitar botão
        this.btnGerar.disabled = false;

        if (result.success) {
            // Mostrar resultado de sucesso
            this.showSuccessModal(result);
        } else {
            // Tratar erro do servidor
            this.handleError(new Error(result.error || 'Erro desconhecido do servidor'));
        }
    }

    showSuccessModal(result) {
        const data = result.data;
        const estatisticas = result.estatisticas;

        // Criar modal de sucesso
        const successModal = `
            <div class="modal fade" id="successModal" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header bg-success text-white">
                            <h5 class="modal-title">
                                <i class="bi bi-check-circle me-2"></i>Memorial Descritivo Gerado!
                            </h5>
                            <button type="button" class="btn-close btn-close-white" 
                                    data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6 class="text-primary">📋 Informações do Projeto</h6>
                                    <p><strong>Projeto:</strong> ${data.projeto_nome}</p>
                                    <p><strong>Cliente:</strong> ${data.cliente}</p>
                                    <p><strong>Hash:</strong> <code>${data.documento_hash}</code></p>
                                </div>
                                <div class="col-md-6">
                                    <h6 class="text-primary">📊 Estatísticas</h6>
                                    <p><strong>Seções:</strong> ${estatisticas.total_secoes}</p>
                                    <p><strong>Palavras:</strong> ${estatisticas.palavras_total}</p>
                                    <p><strong>Qualidade:</strong> ⭐ ${data.qualidade_estimada}/5.0</p>
                                </div>
                            </div>
                            
                            <div class="mt-3">
                                <h6 class="text-primary">📑 Seções Geradas</h6>
                                <div class="row">
                                    ${data.secoes_geradas.map(secao =>
            `<div class="col-md-4 mb-1">
                                            <span class="badge bg-secondary">${secao}</span>
                                        </div>`
        ).join('')}
                                </div>
                            </div>
                            
                            <div class="mt-3">
                                <h6 class="text-primary">🚀 Processamento</h6>
                                <p><strong>Tempo:</strong> ${data.tempo_processamento}</p>
                                <p><strong>Referências:</strong> ${data.referencias_utilizadas} documentos similares</p>
                            </div>
                            
                            <div class="mt-3">
                                <h6 class="text-primary">📄 Prévia do Documento</h6>
                                <div style="max-height: 200px; overflow-y: auto; background: #f8f9fa; padding: 10px; border-radius: 4px;">
                                    <pre style="font-size: 12px; margin: 0;">${data.documento_completo.substring(0, 500)}...</pre>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                Fechar
                            </button>
                            <button type="button" class="btn btn-primary" onclick="downloadMemorial('${data.documento_hash}')">
                                <i class="bi bi-download me-2"></i>Download PDF
                            </button>
                            <button type="button" class="btn btn-info" onclick="visualizarMemorial('${data.documento_hash}')">
                                <i class="bi bi-eye me-2"></i>Visualizar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Remover modal anterior se existir
        const existingModal = document.getElementById('successModal');
        if (existingModal) {
            existingModal.remove();
        }

        // Adicionar novo modal
        document.body.insertAdjacentHTML('beforeend', successModal);

        // Mostrar modal
        const modalInstance = new bootstrap.Modal(document.getElementById('successModal'));
        modalInstance.show();

        // Fechar modal principal
        const mainModalInstance = bootstrap.Modal.getInstance(this.modal);
        if (mainModalInstance) {
            mainModalInstance.hide();
        }

        // Reset form
        this.resetForm();
    }

    handleError(error) {
        // Esconder loading
        if (typeof ProfessionalLoading !== 'undefined') {
            ProfessionalLoading.hide();
        }

        // Reabilitar botão
        this.btnGerar.disabled = false;

        // Mostrar modal de erro
        const errorModal = `
            <div class="modal fade" id="errorModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-danger text-white">
                            <h5 class="modal-title">
                                <i class="bi bi-exclamation-triangle me-2"></i>Erro no Processamento
                            </h5>
                            <button type="button" class="btn-close btn-close-white" 
                                    data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="alert alert-danger" role="alert">
                                <h6 class="alert-heading">Ops! Algo deu errado</h6>
                                <p class="mb-0">${error.message}</p>
                            </div>
                            
                            <h6 class="mt-3">💡 Possíveis soluções:</h6>
                            <ul>
                                <li>Verifique se o arquivo <code>processar_memorial.php</code> existe</li>
                                <li>Verifique se não há erros no PHP (execute debug_memorial.php)</li>
                                <li>Confirme se o banco de dados está conectado</li>
                                <li>Verifique sua conexão com a internet</li>
                                <li>Tente recarregar a página</li>
                            </ul>
                            
                            <div class="mt-3">
                                <small class="text-muted">
                                    <i class="bi bi-clock me-1"></i>
                                    Erro ocorrido em: ${new Date().toLocaleString()}
                                </small>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                Fechar
                            </button>
                            <button type="button" class="btn btn-warning" onclick="window.open('debug_memorial.php', '_blank')">
                                <i class="bi bi-bug me-2"></i>Executar Diagnóstico
                            </button>
                            <button type="button" class="btn btn-primary" onclick="location.reload()">
                                <i class="bi bi-arrow-clockwise me-2"></i>Recarregar Página
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Remover modal anterior se existir
        const existingErrorModal = document.getElementById('errorModal');
        if (existingErrorModal) {
            existingErrorModal.remove();
        }

        // Adicionar modal de erro
        document.body.insertAdjacentHTML('beforeend', errorModal);

        // Mostrar modal
        const modalInstance = new bootstrap.Modal(document.getElementById('errorModal'));
        modalInstance.show();

        // Log do erro no console
        console.error('Erro no processamento do Memorial:', error);
    }

    resetForm() {
        // Reset form
        this.form.reset();
        this.form.classList.remove('was-validated');

        // Reset botão
        this.btnGerar.disabled = false;

        // Limpar campos específicos
        const complexidadeSelect = document.getElementById('complexidade');
        if (complexidadeSelect) {
            complexidadeSelect.value = 'media'; // Valor padrão
        }
    }

    // Método público para abrir modal
    open() {
        const modalInstance = new bootstrap.Modal(this.modal);
        modalInstance.show();
    }

    // Método público para fechar modal
    close() {
        const modalInstance = bootstrap.Modal.getInstance(this.modal);
        if (modalInstance) {
            modalInstance.hide();
        }
    }

    // Método para preencher dados (útil para edição)
    fillData(dados) {
        Object.keys(dados).forEach(key => {
            const element = this.form.elements[key];
            if (element) {
                element.value = dados[key];
            }
        });
    }

    // Método para validar formulário programaticamente
    validate() {
        return this.form.checkValidity();
    }

    // Método para obter dados sem processar
    getData() {
        return this.collectFormData();
    }
}

// =========================================
// FUNÇÕES GLOBAIS DE UTILIDADE
// =========================================

/**
 * Download do memorial em PDF
 */
function downloadMemorial(documentoHash) {
    // Criar link temporário para download
    const link = document.createElement('a');
    link.href = `download_memorial.php?hash=${documentoHash}&format=pdf`;
    link.download = `Memorial_${documentoHash}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Feedback visual
    showToast('success', 'Download iniciado!', 'O arquivo PDF será baixado em instantes.');
}

/**
 * Visualizar memorial
 */
function visualizarMemorial(documentoHash) {
    // Abrir em nova janela/aba
    const url = `visualizar_memorial.php?hash=${documentoHash}`;
    window.open(url, '_blank');

    // Feedback visual
    showToast('info', 'Abrindo visualização...', 'O documento será aberto em nova aba.');
}

/**
 * Compartilhar memorial
 */
function compartilharMemorial(documentoHash) {
    const url = `${window.location.origin}/visualizar_memorial.php?hash=${documentoHash}`;

    if (navigator.share) {
        // API nativa de compartilhamento (mobile)
        navigator.share({
            title: 'Memorial Descritivo - MineDocs',
            url: url
        });
    } else {
        // Copiar para clipboard
        navigator.clipboard.writeText(url).then(() => {
            showToast('success', 'Link copiado!', 'O link foi copiado para sua área de transferência.');
        });
    }
}

/**
 * Mostrar toast notification
 */
function showToast(type, title, message) {
    const toastId = 'toast_' + Date.now();
    const bgClass = type === 'success' ? 'bg-success' :
        type === 'error' ? 'bg-danger' :
            type === 'warning' ? 'bg-warning' : 'bg-info';

    const toastHtml = `
        <div class="toast align-items-center text-white ${bgClass} border-0" 
             id="${toastId}" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    <strong>${title}</strong><br>
                    <small>${message}</small>
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" 
                        data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    `;

    // Container de toasts
    let toastContainer = document.getElementById('toastContainer');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toastContainer';
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        toastContainer.style.zIndex = '9999';
        document.body.appendChild(toastContainer);
    }

    toastContainer.insertAdjacentHTML('beforeend', toastHtml);

    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, {
        autohide: true,
        delay: 5000
    });

    toast.show();

    // Remover elemento após esconder
    toastElement.addEventListener('hidden.bs.toast', () => {
        toastElement.remove();
    });
}

/**
 * Avaliar qualidade do documento gerado
 */
function avaliarMemorial(documentoHash, nota, feedback = '') {
    fetch('avaliar_memorial.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            documento_hash: documentoHash,
            nota: nota,
            feedback: feedback
        })
    })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showToast('success', 'Avaliação enviada!', 'Obrigado pelo seu feedback.');
            } else {
                showToast('error', 'Erro', 'Não foi possível enviar a avaliação.');
            }
        })
        .catch(error => {
            showToast('error', 'Erro', 'Erro de conexão ao enviar avaliação.');
        });
}

// =========================================
// INICIALIZAÇÃO
// =========================================

// Inicializar quando DOM estiver pronto
document.addEventListener('DOMContentLoaded', function () {
    // Verificar se ProfessionalLoading está disponível
    if (typeof ProfessionalLoading === 'undefined') {
        console.warn('ProfessionalLoading não encontrado. Inclua o componente de loading.');
    }

    // Verificar se elementos necessários existem
    if (!document.getElementById('memorialDescritivoForm')) {
        console.warn('Formulário memorial não encontrado. Inclua o modal memorial-descritivo-modal.php');
        return;
    }

    // Criar instância global
    window.memorialDescritivoModal = new MemorialDescritivoModal();
    console.log('✅ MemorialDescritivoModal inicializado');
});

// Métodos de conveniência globais
window.openMemorialDescritivo = function () {
    if (window.memorialDescritivoModal) {
        window.memorialDescritivoModal.open();
    } else {
        console.error('MemorialDescritivoModal não inicializado');
    }
};

window.closeMemorialDescritivo = function () {
    if (window.memorialDescritivoModal) {
        window.memorialDescritivoModal.close();
    }
};

// =========================================
// HANDLERS DE EVENTOS GLOBAIS
// =========================================

// Tratar erros globais AJAX
window.addEventListener('unhandledrejection', function (event) {
    console.error('Erro não tratado:', event.reason);

    if (event.reason.message && event.reason.message.includes('memorial')) {
        showToast('error', 'Erro no Sistema', 'Ocorreu um erro inesperado. Tente novamente.');
    }
});

// Debug: log de todas as interações (apenas em desenvolvimento)
if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    console.log('🔧 Modo DEBUG ativado');

    document.addEventListener('click', function (e) {
        if (e.target.closest('#memorialDescritivoForm')) {
            console.log('🖱️ Clique no formulário:', e.target);
        }
    });

    // Log de requisições fetch
    const originalFetch = window.fetch;
    window.fetch = function (...args) {
        console.log('🌐 Fetch requisição:', args);
        return originalFetch.apply(this, args)
            .then(response => {
                console.log('📥 Fetch resposta:', response);
                return response;
            });
    };
}