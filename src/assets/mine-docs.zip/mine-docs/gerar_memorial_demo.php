<?php
$variavel = "";
// Gerar documento Word
$html = '<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Memorial Descritivo</title></head>
<body>
<h1>MEMORIAL DESCRITIVO - PROJETO DEMONSTRAÇÃO</h1>
<p><strong>Cliente:</strong> Vale S.A.</p>
<p><strong>Projeto:</strong> Expansão Mina Córrego do Feijão</p>
<p><strong>Localização:</strong> Brumadinho, Minas Gerais</p>
<h2>1. OBJETIVO</h2>
<p>Este memorial descritivo apresenta os procedimentos técnicos para operação de mineração de ferro...</p>
<h2>2. LOCALIZAÇÃO</h2>
<p>O projeto está localizado em Brumadinho, Minas Gerais, com acesso pela BR-040...</p>
<h2>3. METODOLOGIA</h2>
<p>Será utilizado método de lavra a céu aberto com bancadas de 10 metros...</p>
<h2>4. INVESTIMENTO</h2>
<p>Investimento total estimado: R$ 85.000.000,00</p>
<h2>5. CONCLUSÃO</h2>
<p>O projeto demonstra viabilidade técnica e econômica para mineração de ferro.</p>
<p><br><br>___________________________<br>Engenheiro Responsável</p>
</body>
</html>';

header("Content-Type: application/msword");
header("Content-Disposition: attachment; filename=Memorial_" . date('Y-m-d_His') . ".doc");
echo $html;
exit;