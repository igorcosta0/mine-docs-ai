<?php
// =========================================
// CLASSES/MEMORIALDESCRITIVO.PHP
// =========================================

require_once __DIR__ . '/../config/database.php';

class MemorialDescritivo
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // =========================================
    // MÉTODOS DE INSERÇÃO
    // =========================================

    /**
     * Inserir novo documento de referência
     */
    public function inserirDocumentoReferencia($dados)
    {
        try {
            $this->db->beginTransaction();

            // Validar dados obrigatórios
            $this->validarDadosObrigatorios($dados);

            // Inserir documento principal
            $query = "
                INSERT INTO documentos_referencia (
                    tipo_documento, projeto_nome, cliente, localizacao,
                    categoria_projeto, tipo_mineracao, porte_projeto, complexidade,
                    area_hectares, investimento_estimado, duracao_meses,
                    engenheiro_responsavel, data_criacao
                ) VALUES (
                    :tipo_documento, :projeto_nome, :cliente, :localizacao,
                    :categoria_projeto, :tipo_mineracao, :porte_projeto, :complexidade,
                    :area_hectares, :investimento_estimado, :duracao_meses,
                    :engenheiro_responsavel, :data_criacao
                )
            ";

            $params = [
                'tipo_documento' => 'memorial_descritivo',
                'projeto_nome' => $dados['projeto_nome'],
                'cliente' => $dados['cliente'],
                'localizacao' => $dados['localizacao'],
                'categoria_projeto' => $dados['categoria_projeto'],
                'tipo_mineracao' => $dados['tipo_mineracao'],
                'porte_projeto' => $dados['porte_projeto'],
                'complexidade' => $dados['complexidade'],
                'area_hectares' => $dados['area_hectares'] ?? null,
                'investimento_estimado' => $dados['investimento_estimado'] ?? null,
                'duracao_meses' => $dados['duracao_meses'] ?? null,
                'engenheiro_responsavel' => $dados['engenheiro_responsavel'] ?? null,
                'data_criacao' => date('Y-m-d')
            ];

            $documentoId = $this->db->insert($query, $params);

            // Inserir seções se fornecidas
            if (isset($dados['secoes']) && is_array($dados['secoes'])) {
                $this->inserirSecoes($documentoId, $dados['secoes']);
            }

            $this->db->commit();

            return [
                'success' => true,
                'documento_id' => $documentoId,
                'message' => 'Documento inserido com sucesso'
            ];
        } catch (Exception $e) {
            $this->db->rollback();
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Inserir seções do documento
     */
    private function inserirSecoes($documentoId, $secoes)
    {
        $query = "
            INSERT INTO secoes_conteudo (
                documento_id, secao_nome, ordem_secao, conteudo, 
                palavras_chave, tom_linguagem
            ) VALUES (
                :documento_id, :secao_nome, :ordem_secao, :conteudo,
                :palavras_chave, :tom_linguagem
            )
        ";

        foreach ($secoes as $ordem => $secao) {
            $params = [
                'documento_id' => $documentoId,
                'secao_nome' => $secao['nome'],
                'ordem_secao' => $ordem + 1,
                'conteudo' => $secao['conteudo'],
                'palavras_chave' => json_encode($secao['palavras_chave'] ?? []),
                'tom_linguagem' => $secao['tom_linguagem'] ?? 'tecnico'
            ];

            $this->db->execute($query, $params);
        }
    }

    // =========================================
    // MÉTODOS DE BUSCA
    // =========================================

    /**
     * Buscar documentos similares para IA
     */
    public function buscarDocumentosSimilares($criterios, $limite = 5)
    {
        try {
            // Chamar procedure do banco
            $query = "CALL BuscarDocumentosSimilares(?, ?, ?, ?, ?, ?)";

            $params = [
                'memorial_descritivo',
                $criterios['categoria_projeto'],
                $criterios['tipo_mineracao'],
                $criterios['porte_projeto'],
                $criterios['complexidade'],
                $limite
            ];

            $documentos = $this->db->fetchAll($query, $params);

            // Buscar seções dos documentos similares
            foreach ($documentos as &$doc) {
                $doc['secoes'] = $this->buscarSecoesDocumento($doc['id']);
            }

            return [
                'success' => true,
                'documentos' => $documentos,
                'total' => count($documentos)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Buscar seções específicas de um documento
     */
    public function buscarSecoesDocumento($documentoId)
    {
        $query = "
            SELECT secao_nome, conteudo, palavras_chave, tom_linguagem
            FROM secoes_conteudo 
            WHERE documento_id = :documento_id 
            ORDER BY ordem_secao ASC
        ";

        $secoes = $this->db->fetchAll($query, ['documento_id' => $documentoId]);

        $resultado = [];
        foreach ($secoes as $secao) {
            $resultado[$secao['secao_nome']] = [
                'conteudo' => $secao['conteudo'],
                'palavras_chave' => json_decode($secao['palavras_chave'] ?? '[]', true),
                'tom_linguagem' => $secao['tom_linguagem']
            ];
        }

        return $resultado;
    }

    /**
     * Obter template do memorial descritivo
     */
    public function obterTemplate()
    {
        $query = "
            SELECT * FROM templates_documento 
            WHERE tipo_documento = 'memorial_descritivo' 
            AND ativo = 1 
            ORDER BY created_at DESC 
            LIMIT 1
        ";

        $template = $this->db->fetchOne($query);

        if ($template) {
            // Decodificar JSONs
            $template['secoes_obrigatorias'] = json_decode($template['secoes_obrigatorias'], true);
            $template['secoes_opcionais'] = json_decode($template['secoes_opcionais'] ?? '[]', true);
            $template['estrutura_template'] = json_decode($template['estrutura_template'], true);
            $template['prompts_ia'] = json_decode($template['prompts_ia'], true);
            $template['formatacao_regras'] = json_decode($template['formatacao_regras'] ?? '[]', true);
        }

        return $template;
    }

    // =========================================
    // MÉTODOS DE ANÁLISE
    // =========================================

    /**
     * Obter estatísticas dos memoriais descritivos
     */
    public function obterEstatisticas()
    {
        try {
            $stats = [];

            // Total de memoriais
            $stats['total'] = $this->db->count(
                'documentos_referencia',
                ['tipo_documento = ?', 'status = ?'],
                ['memorial_descritivo', 'ativo']
            );

            // Por categoria
            $query = "
                SELECT categoria_projeto, COUNT(*) as total
                FROM documentos_referencia 
                WHERE tipo_documento = 'memorial_descritivo' AND status = 'ativo'
                GROUP BY categoria_projeto
            ";
            $stats['por_categoria'] = $this->db->fetchAll($query);

            // Por tipo de mineração
            $query = "
                SELECT tipo_mineracao, COUNT(*) as total
                FROM documentos_referencia 
                WHERE tipo_documento = 'memorial_descritivo' AND status = 'ativo'
                GROUP BY tipo_mineracao
            ";
            $stats['por_tipo_mineracao'] = $this->db->fetchAll($query);

            // Qualidade média
            $query = "
                SELECT AVG(qualidade_avaliacao) as media_qualidade
                FROM documentos_referencia 
                WHERE tipo_documento = 'memorial_descritivo' AND status = 'ativo'
            ";
            $result = $this->db->fetchOne($query);
            $stats['qualidade_media'] = round($result['media_qualidade'] ?? 0, 1);

            // Mais utilizados
            $query = "
                SELECT projeto_nome, cliente, frequencia_uso
                FROM documentos_referencia 
                WHERE tipo_documento = 'memorial_descritivo' AND status = 'ativo'
                ORDER BY frequencia_uso DESC
                LIMIT 5
            ";
            $stats['mais_utilizados'] = $this->db->fetchAll($query);

            return [
                'success' => true,
                'estatisticas' => $stats
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Extrair palavras-chave de um texto
     */
    public function extrairPalavrasChave($texto, $limite = 10)
    {
        // Lista de palavras irrelevantes (stop words)
        $stopWords = [
            'a',
            'o',
            'e',
            'de',
            'do',
            'da',
            'para',
            'com',
            'em',
            'no',
            'na',
            'por',
            'um',
            'uma',
            'ao',
            'aos',
            'as',
            'os',
            'que',
            'se',
            'não',
            'mais',
            'como',
            'mas',
            'foi',
            'ser',
            'tem',
            'são',
            'este',
            'esta',
            'esse',
            'essa',
            'seu',
            'sua',
            'seus',
            'suas'
        ];

        // Limpar e normalizar texto
        $texto = strtolower($texto);
        $texto = preg_replace('/[^a-záàâãéêíóôõúçñ\s]/u', '', $texto);

        // Dividir em palavras
        $palavras = array_filter(explode(' ', $texto), function ($palavra) use ($stopWords) {
            return strlen($palavra) > 3 && !in_array($palavra, $stopWords);
        });

        // Contar frequência
        $frequencia = array_count_values($palavras);
        arsort($frequencia);

        // Retornar as mais frequentes
        return array_slice(array_keys($frequencia), 0, $limite);
    }

    // =========================================
    // MÉTODOS DE VALIDAÇÃO
    // =========================================

    /**
     * Validar dados obrigatórios
     */
    private function validarDadosObrigatorios($dados)
    {
        $obrigatorios = [
            'projeto_nome' => 'Nome do projeto',
            'cliente' => 'Cliente',
            'localizacao' => 'Localização',
            'categoria_projeto' => 'Categoria do projeto',
            'tipo_mineracao' => 'Tipo de mineração',
            'porte_projeto' => 'Porte do projeto',
            'complexidade' => 'Complexidade'
        ];

        $erros = [];
        foreach ($obrigatorios as $campo => $nome) {
            if (empty($dados[$campo])) {
                $erros[] = "Campo obrigatório: {$nome}";
            }
        }

        if (!empty($erros)) {
            throw new Exception("Dados inválidos: " . implode(', ', $erros));
        }

        // Validar valores dos ENUMs
        $this->validarEnums($dados);
    }

    /**
     * Validar valores dos campos ENUM
     */
    private function validarEnums($dados)
    {
        $enums = [
            'categoria_projeto' => ['lavra', 'beneficiamento', 'infraestrutura', 'ambiental', 'pesquisa'],
            'tipo_mineracao' => ['ferro', 'ouro', 'cobre', 'bauxita', 'manganes', 'niquel', 'fosfato', 'outros'],
            'porte_projeto' => ['pequeno', 'medio', 'grande'],
            'complexidade' => ['baixa', 'media', 'alta']
        ];

        foreach ($enums as $campo => $valores) {
            if (isset($dados[$campo]) && !in_array($dados[$campo], $valores)) {
                throw new Exception("Valor inválido para {$campo}: {$dados[$campo]}");
            }
        }
    }

    // =========================================
    // MÉTODOS DE UTILIDADE
    // =========================================

    /**
     * Incrementar uso de documento
     */
    public function incrementarUso($documentoId)
    {
        $query = "CALL IncrementarUsoDocumento(?)";
        return $this->db->execute($query, [$documentoId]);
    }

    /**
     * Avaliar qualidade do documento
     */
    public function avaliarQualidade($documentoId, $nota)
    {
        if ($nota < 1 || $nota > 5) {
            throw new Exception("Nota deve estar entre 1 e 5");
        }

        $query = "
            UPDATE documentos_referencia 
            SET qualidade_avaliacao = :nota 
            WHERE id = :id
        ";

        return $this->db->execute($query, [
            'nota' => $nota,
            'id' => $documentoId
        ]);
    }

    /**
     * Buscar por palavra-chave
     */
    public function buscarPorPalavraChave($palavraChave, $limite = 10)
    {
        $query = "
            SELECT DISTINCT dr.*, 
                   GROUP_CONCAT(sc.secao_nome) as secoes_encontradas
            FROM documentos_referencia dr
            JOIN secoes_conteudo sc ON dr.id = sc.documento_id
            WHERE dr.tipo_documento = 'memorial_descritivo' 
            AND dr.status = 'ativo'
            AND (
                dr.projeto_nome LIKE :palavra OR
                sc.conteudo LIKE :palavra OR
                JSON_SEARCH(sc.palavras_chave, 'one', :palavra_simples) IS NOT NULL
            )
            GROUP BY dr.id
            ORDER BY dr.qualidade_avaliacao DESC, dr.frequencia_uso DESC
            LIMIT :limite
        ";

        return $this->db->fetchAll($query, [
            'palavra' => "%{$palavraChave}%",
            'palavra_simples' => $palavraChave,
            'limite' => $limite
        ]);
    }

    /**
     * Obter documento completo por ID
     */
    public function obterDocumentoCompleto($documentoId)
    {
        // Buscar documento
        $query = "SELECT * FROM documentos_referencia WHERE id = :id";
        $documento = $this->db->fetchOne($query, ['id' => $documentoId]);

        if (!$documento) {
            return null;
        }

        // Buscar seções
        $documento['secoes'] = $this->buscarSecoesDocumento($documentoId);

        return $documento;
    }
}
