<!-- ========================================= -->
<!-- PROFESSIONAL LOADING - COMPONENTE REUTILIZÁVEL -->
<!-- ========================================= -->

<!-- HTML Structure -->
<div class="professional-loading-overlay" id="professionalLoading">
    <div class="professional-loading">
        <div class="loading-container">
            <!-- Logo/Ícone -->
            <div class="loading-icon">
                <i class="bi bi-cpu-fill"></i>
            </div>

            <!-- Título Principal -->
            <h4 class="loading-title" id="loadingTitle">Processando...</h4>

            <!-- Etapa Atual -->
            <div class="loading-stage">
                <span id="currentStage">Inicializando sistema...</span>
            </div>

            <!-- Barra de Progresso -->
            <div class="progress-container">
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill"></div>
                </div>
                <div class="progress-percentage" id="progressPercentage">0%</div>
            </div>

            <!-- Lista de Etapas -->
            <div class="stages-list" id="stagesList">
                <!-- Etapas serão inseridas dinamicamente -->
            </div>

            <!-- Informações Adicionais -->
            <div class="loading-info">
                <small class="text-muted">
                    <i class="bi bi-shield-check me-1"></i>
                    <span id="loadingInfoText">Processamento seguro e privado</span>
                </small>
            </div>
        </div>
    </div>
</div>

<!-- CSS Styles -->
<style>
    /* ========================================= */
    /* PROFESSIONAL LOADING - CSS */
    /* ========================================= */

    .professional-loading-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(255, 255, 255, 0.98);
        backdrop-filter: blur(8px);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
        opacity: 0;
        visibility: hidden;
        transition: all 0.4s ease;
    }

    .professional-loading-overlay.show {
        opacity: 1;
        visibility: visible;
    }

    .professional-loading {
        text-align: center;
        max-width: 500px;
        width: 90%;
        padding: 40px;
        background: white;
        border-radius: 16px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
        border: 1px solid rgba(212, 175, 55, 0.2);
        position: relative;
        animation: slideInScale 0.5s ease-out;
    }

    @keyframes slideInScale {
        from {
            opacity: 0;
            transform: translateY(30px) scale(0.9);
        }

        to {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
    }

    .loading-container {
        position: relative;
    }

    /* Ícone de Loading */
    .loading-icon {
        width: 80px;
        height: 80px;
        margin: 0 auto 30px;
        background: linear-gradient(135deg, var(--accent-gold, #d4af37), #c19b26);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 35px;
        color: white;
        animation: pulse-glow 2s ease-in-out infinite alternate;
        position: relative;
        overflow: hidden;
    }

    .loading-icon::before {
        content: '';
        position: absolute;
        top: -2px;
        left: -2px;
        right: -2px;
        bottom: -2px;
        background: conic-gradient(var(--accent-gold, #d4af37), transparent, var(--accent-gold, #d4af37));
        border-radius: 50%;
        z-index: -1;
        animation: rotate 2s linear infinite;
    }

    @keyframes pulse-glow {
        0% {
            box-shadow: 0 0 20px rgba(212, 175, 55, 0.4);
            transform: scale(1);
        }

        100% {
            box-shadow: 0 0 40px rgba(212, 175, 55, 0.8);
            transform: scale(1.05);
        }
    }

    @keyframes rotate {
        from {
            transform: rotate(0deg);
        }

        to {
            transform: rotate(360deg);
        }
    }

    /* Título */
    .loading-title {
        color: var(--primary-navy, #1a365d);
        font-size: 24px;
        font-weight: 700;
        margin-bottom: 15px;
        letter-spacing: -0.5px;
    }

    .loading-stage {
        color: var(--text-medium, #4a5568);
        font-size: 16px;
        font-weight: 500;
        margin-bottom: 25px;
        min-height: 24px;
        transition: all 0.3s ease;
    }

    /* Barra de Progresso */
    .progress-container {
        margin-bottom: 30px;
        position: relative;
    }

    .progress-bar {
        height: 8px;
        background: #f0f0f0;
        border-radius: 10px;
        overflow: hidden;
        position: relative;
        margin-bottom: 10px;
    }

    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--accent-gold, #d4af37), #c19b26);
        border-radius: 10px;
        width: 0%;
        transition: width 0.3s ease;
        position: relative;
        overflow: hidden;
    }

    .progress-fill::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
        animation: shimmer 2s infinite;
    }

    @keyframes shimmer {
        0% {
            transform: translateX(-100%);
        }

        100% {
            transform: translateX(100%);
        }
    }

    .progress-percentage {
        color: var(--text-dark, #1a202c);
        font-size: 14px;
        font-weight: 600;
        text-align: center;
    }

    /* Lista de Etapas */
    .stages-list {
        text-align: left;
        margin-bottom: 25px;
    }

    .stage-item {
        display: flex;
        align-items: center;
        padding: 12px 0;
        border-bottom: 1px solid #f0f0f0;
        transition: all 0.3s ease;
        position: relative;
    }

    .stage-item:last-child {
        border-bottom: none;
    }

    .stage-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: #f8f9fa;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 15px;
        font-size: 16px;
        color: var(--text-light, #718096);
        transition: all 0.3s ease;
        border: 2px solid #e9ecef;
    }

    .stage-text {
        flex: 1;
        font-size: 14px;
        color: var(--text-medium, #4a5568);
        font-weight: 500;
    }

    .stage-status {
        width: 20px;
        height: 20px;
        margin-left: 15px;
    }

    /* Estados das etapas */
    .stage-item.active .stage-icon {
        background: var(--accent-gold, #d4af37);
        color: white;
        border-color: var(--accent-gold, #d4af37);
        animation: pulse-stage 1.5s ease-in-out infinite;
    }

    .stage-item.active .stage-text {
        color: var(--text-dark, #1a202c);
        font-weight: 600;
    }

    .stage-item.completed .stage-icon {
        background: var(--primary-blue, #2c5282);
        color: white;
        border-color: var(--primary-blue, #2c5282);
    }

    .stage-item.completed .stage-text {
        color: var(--text-dark, #1a202c);
    }

    .stage-item.completed .stage-status::after {
        content: '✓';
        color: var(--primary-blue, #2c5282);
        font-weight: bold;
        font-size: 16px;
    }

    @keyframes pulse-stage {
        0% {
            box-shadow: 0 0 0 0 rgba(212, 175, 55, 0.7);
        }

        70% {
            box-shadow: 0 0 0 10px rgba(212, 175, 55, 0);
        }

        100% {
            box-shadow: 0 0 0 0 rgba(212, 175, 55, 0);
        }
    }

    /* Informações adicionais */
    .loading-info {
        text-align: center;
        padding-top: 20px;
        border-top: 1px solid #f0f0f0;
    }

    .loading-info small {
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--text-light, #718096);
        font-size: 13px;
    }

    /* Responsividade */
    @media (max-width: 576px) {
        .professional-loading {
            padding: 30px 20px;
            margin: 20px;
        }

        .loading-icon {
            width: 60px;
            height: 60px;
            font-size: 28px;
            margin-bottom: 20px;
        }

        .loading-title {
            font-size: 20px;
        }
    }

    /* Variante para overlay em modal (não fullscreen) */
    .professional-loading-overlay.modal-overlay {
        position: absolute;
        z-index: 1000;
    }
</style>

<!-- JavaScript Class -->
<script>
    class ProfessionalLoading {
        constructor(containerId = 'professionalLoading') {
            this.container = document.getElementById(containerId);
            this.progressFill = document.getElementById('progressFill');
            this.progressPercentage = document.getElementById('progressPercentage');
            this.currentStageElement = document.getElementById('currentStage');
            this.stagesList = document.getElementById('stagesList');
            this.loadingTitle = document.getElementById('loadingTitle');
            this.loadingInfoText = document.getElementById('loadingInfoText');

            this.currentProgress = 0;
            this.isRunning = false;
        }

        // Configurar e mostrar loading
        show(config = {}) {
            const defaultConfig = {
                title: 'Processando...',
                infoText: 'Processamento seguro e privado',
                stages: [{
                        icon: 'bi-search',
                        text: 'Inicializando...',
                        duration: 2000
                    },
                    {
                        icon: 'bi-gear-fill',
                        text: 'Processando...',
                        duration: 3000
                    },
                    {
                        icon: 'bi-check-circle',
                        text: 'Finalizando...',
                        duration: 2000
                    }
                ]
            };

            const finalConfig = {
                ...defaultConfig,
                ...config
            };

            // Configurar textos
            this.loadingTitle.textContent = finalConfig.title;
            this.loadingInfoText.textContent = finalConfig.infoText;

            // Criar etapas
            this.createStages(finalConfig.stages);

            // Reset estados
            this.reset();

            // Mostrar overlay
            this.container.classList.add('show');
            this.isRunning = true;

            // Iniciar animação
            this.runStages(finalConfig.stages);

            return this;
        }

        // Esconder loading
        hide() {
            this.container.classList.remove('show');
            this.isRunning = false;
            return this;
        }

        // Criar HTML das etapas
        createStages(stages) {
            this.stagesList.innerHTML = '';

            stages.forEach((stage, index) => {
                const stageElement = document.createElement('div');
                stageElement.className = 'stage-item';
                stageElement.id = `stage-${index}`;

                stageElement.innerHTML = `
                <div class="stage-icon">
                    <i class="${stage.icon}"></i>
                </div>
                <div class="stage-text">${stage.text}</div>
                <div class="stage-status"></div>
            `;

                this.stagesList.appendChild(stageElement);
            });
        }

        // Executar animação das etapas
        runStages(stages) {
            let stageIndex = 0;

            const runStage = (index) => {
                if (index >= stages.length || !this.isRunning) return;

                const stage = stages[index];
                const stageElement = document.getElementById(`stage-${index}`);
                const targetProgress = ((index + 1) / stages.length) * 100;

                // Atualizar texto da etapa atual
                this.currentStageElement.textContent = stage.text;

                // Marcar etapa como ativa
                if (stageElement) stageElement.classList.add('active');

                // Animar progresso
                const progressDuration = stage.duration;
                const progressInterval = 20;
                const progressStep = (targetProgress - this.currentProgress) / (progressDuration / progressInterval);

                const progressTimer = setInterval(() => {
                    if (!this.isRunning) {
                        clearInterval(progressTimer);
                        return;
                    }

                    this.currentProgress += progressStep;

                    if (this.currentProgress >= targetProgress) {
                        this.currentProgress = targetProgress;
                        clearInterval(progressTimer);

                        // Marcar etapa como completa
                        if (stageElement) {
                            stageElement.classList.remove('active');
                            stageElement.classList.add('completed');
                        }

                        // Próxima etapa
                        setTimeout(() => runStage(index + 1), 200);
                    }

                    // Atualizar UI
                    this.updateProgress();
                }, progressInterval);
            };

            runStage(0);
        }

        // Atualizar UI do progresso
        updateProgress() {
            this.progressFill.style.width = this.currentProgress + '%';
            this.progressPercentage.textContent = Math.round(this.currentProgress) + '%';
        }

        // Reset todos os estados
        reset() {
            this.currentProgress = 0;
            this.updateProgress();
            this.currentStageElement.textContent = 'Inicializando sistema...';

            // Reset etapas
            const stageItems = this.stagesList.querySelectorAll('.stage-item');
            stageItems.forEach(stage => {
                stage.classList.remove('active', 'completed');
            });
        }

        // Método estático para uso rápido
        static show(config) {
            if (!window.professionalLoadingInstance) {
                window.professionalLoadingInstance = new ProfessionalLoading();
            }
            return window.professionalLoadingInstance.show(config);
        }

        static hide() {
            if (window.professionalLoadingInstance) {
                return window.professionalLoadingInstance.hide();
            }
        }
    }

    // Disponibilizar globalmente
    window.ProfessionalLoading = ProfessionalLoading;
</script>