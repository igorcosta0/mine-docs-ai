<?php
// Configuração dos tipos de documentos
$documentTypes = [
    [
        'id' => 'developer-modal',
        'title' => 'Critério de Medição',
        'description' => 'Metodologias e padrões para medição e acompanhamento de execução.',
        'icon' => 'bi-bullseye'
    ],
    [
        'id' => 'developer-modal',
        'title' => 'Critério de Projeto',
        'description' => 'Diretrizes e parâmetros técnicos fundamentais para desenvolvimento de projetos.',
        'icon' => 'bi-diagram-3'
    ],
    [
        'id' => 'developer-modal',
        'title' => 'Especificação de Serviços',
        'description' => 'Detalhamento técnico dos serviços a serem executados no projeto.',
        'icon' => 'bi-gear-fill'
    ],
    [
        'id' => 'developer-modal',
        'title' => 'Especificação Geral',
        'description' => 'Documento abrangente com requisitos gerais e condições do projeto.',
        'icon' => 'bi-file-earmark-text'
    ],
    [
        'id' => 'developer-modal',
        'title' => 'Especificação Técnica',
        'description' => 'Detalhamentos técnicos específicos para equipamentos e materiais.',
        'icon' => 'bi-cpu'
    ],
    [
        'id' => 'developer-modal',
        'title' => 'Estudo de Demanda',
        'description' => 'Análise prospectiva de necessidades e requisitos futuros do projeto.',
        'icon' => 'bi-bar-chart',
        'status' => 'development'
    ],
    [
        'id' => 'developer-modal',
        'title' => 'Folha de Dados',
        'description' => 'Compilação organizada de informações técnicas e especificações de equipamentos.',
        'icon' => 'bi-table'
    ],
    [
        'id' => 'developer-modal',
        'title' => 'Manual de Operação',
        'description' => 'Guia completo para operação, manutenção e procedimentos técnicos.',
        'icon' => 'bi-tools'
    ],
    [
        'id' => 'developer-modal',
        'title' => 'Memória de Cálculo',
        'description' => 'Documentação estruturada de cálculos e metodologias aplicadas em projetos de engenharia.',
        'icon' => 'bi-calculator'
    ],
    [
        'id' => 'memorial-descritivo',
        'title' => 'Memorial Descritivo',
        'description' => 'Descrição detalhada das características e funcionamento do projeto.',
        'icon' => 'bi-book'
    ],
    [
        'id' => 'developer-modal',
        'title' => 'Parecer Técnico',
        'description' => 'Análises técnicas especializadas e recomendações profissionais.',
        'icon' => 'bi-search'
    ],
    [
        'id' => 'developer-modal',
        'title' => 'Planilha de Quantidades',
        'description' => 'Levantamento quantitativo de materiais, equipamentos e serviços necessários.',
        'icon' => 'bi-graph-up'
    ],
    [
        'id' => 'developer-modal',
        'title' => 'Requisição Técnica',
        'description' => 'Solicitações formais para aquisição de materiais e serviços técnicos.',
        'icon' => 'bi-clipboard-check'
    ]
];

// Função para obter a classe CSS do status
function getStatusClass($status)
{
    switch ($status) {
        case 'development':
            return 'in-development';
        case 'beta':
            return 'beta';
        default:
            return '';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MineDocs - Gestão de Documentos Técnicos</title>

    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>

<body>
    <!-- Header -->
    <header class="custom-header">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center py-3">
                <div class="d-flex align-items-center">
                    <div>
                        <div class="logo">MineDocs</div>
                    </div>
                </div>

                <div class="d-flex align-items-center">
                    <div class="user-info d-flex align-items-center gap-3 px-3 py-2">
                        <div class="user-avatar">AD</div>
                        <div class="d-none d-md-block">
                            <h6 class="mb-0 fw-semibold">Admin User</h6>
                            <small class="text-muted">Engenheiro Senior</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container-fluid p-2 p-md-3 p-lg-4">
        <main class="py-4 py-md-5">
            <!-- Page Header -->
            <div class="text-center mb-4 mb-md-5">
                <h1 class="page-title mb-3">Selecione o Tipo de Documento</h1>
                <div class="divider mx-auto mt-4"></div>
            </div>

            <!-- Search Section -->
            <div class="row justify-content-center mb-4">
                <div class="col-lg-6 col-md-8">
                    <div class="position-relative">
                        <input type="text" id="searchInput"
                            class="form-control search-input rounded-pill"
                            placeholder="Buscar tipo de documento...">
                    </div>
                </div>
            </div>

            <!-- Documents Grid -->
            <div class="row g-3 g-md-4" id="documentsGrid">
                <?php foreach ($documentTypes as $index => $doc): ?>
                    <div class="col-12 col-sm-6 col-lg-4 col-xl-3">
                        <div class="card document-card h-100 fade-in-up"
                            data-bs-toggle="modal"
                            data-bs-target="#<?= $doc['id'] ?>"
                            data-title="<?= htmlspecialchars($doc['title']) ?>">
                            <div class="card-body d-flex flex-column">
                                <div class="card-icon mb-3">
                                    <i class="<?= $doc['icon'] ?>"></i>
                                </div>
                                <h5 class="card-title"><?= htmlspecialchars($doc['title']) ?></h5>
                                <p class="card-description flex-grow-1">
                                    <?= htmlspecialchars($doc['description']) ?>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </main>
    </div>

    <!-- Incluir Modais -->
    <?php
    include 'components/professional-loading.php';
    include 'modals/developer-modal.php';
    include 'modals/memorial-descritivo-modal.php';
    ?>

    <!-- Bootstrap 5.3 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Memorial Descritivo Integration -->
    <script src="js/memorial-integration.js"></script>

    <script>
        // Funcionalidade de busca
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('searchInput');
            const documentsGrid = document.getElementById('documentsGrid');
            const documentCards = documentsGrid.querySelectorAll('.document-card');

            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase().trim();

                documentCards.forEach(card => {
                    const cardElement = card.closest('.col-12, .col-sm-6, .col-lg-4, .col-xl-3');
                    const title = card.getAttribute('data-title').toLowerCase();
                    const description = card.querySelector('.card-description').textContent.toLowerCase();

                    if (searchTerm === '' || title.includes(searchTerm) || description.includes(searchTerm)) {
                        cardElement.style.display = '';
                    } else {
                        cardElement.style.display = 'none';
                    }
                });
            });

            // Limpar busca ao pressionar ESC
            searchInput.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    this.value = '';
                    this.dispatchEvent(new Event('input'));
                    this.blur();
                }
            });

            // Animação de entrada dos cards
            const observer = new IntersectionObserver((entries) => {
                entries.forEach((entry, index) => {
                    if (entry.isIntersecting) {
                        setTimeout(() => {
                            entry.target.classList.add('show');
                        }, index * 50);
                        observer.unobserve(entry.target);
                    }
                });
            });

            document.querySelectorAll('.fade-in-up').forEach(card => {
                observer.observe(card);
            });
        });
    </script>
</body>

</html>