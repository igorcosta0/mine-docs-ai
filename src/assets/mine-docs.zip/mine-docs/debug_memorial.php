<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MineDocs - Diagnóstico Completo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f8f9fa;
        }

        .container {
            max-width: 1200px;
            margin: 40px auto;
        }

        .logo {
            font-size: 32px;
            font-weight: 700;
            color: #1a365d;
            letter-spacing: 2px;
        }

        .success {
            color: #28a745;
            background: #d4edda;
            padding: 10px;
            border-left: 4px solid #28a745;
            margin: 10px 0;
        }

        .error {
            color: #dc3545;
            background: #f8d7da;
            padding: 10px;
            border-left: 4px solid #dc3545;
            margin: 10px 0;
        }

        .warning {
            color: #856404;
            background: #fff3cd;
            padding: 10px;
            border-left: 4px solid #ffc107;
            margin: 10px 0;
        }

        .info {
            color: #0c5460;
            background: #d1ecf1;
            padding: 10px;
            border-left: 4px solid #17a2b8;
            margin: 10px 0;
        }

        pre {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            font-size: 12px;
            overflow-x: auto;
        }

        .section {
            background: white;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .badge-custom {
            background: #1a365d;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="text-center mb-4">
            <div class="logo">MineDocs</div>
            <p class="text-muted">Diagnóstico Completo do Sistema</p>
            <small class="text-muted">🕒 <?= date('d/m/Y H:i:s') ?></small>
        </div>

        <?php
        // =========================================
        // DEBUG_MEMORIAL.PHP - Diagnóstico Completo
        // =========================================

        // Capturar todos os erros
        error_reporting(E_ALL);
        ini_set('display_errors', 1);

        $diagnostico = [];
        $erros_criticos = 0;
        $avisos = 0;

        echo "<div class='section'>";
        echo "<h2>🔍 1. VERIFICAÇÃO DE ARQUIVOS ESSENCIAIS</h2>";

        // Lista de arquivos obrigatórios
        $arquivos_obrigatorios = [
            'config/database.php' => 'Configuração do banco de dados',
            'classes/MemorialDescritivo.php' => 'Classe principal do Memorial',
            'modals/memorial-descritivo-modal.php' => 'Modal do formulário',
            'js/memorial-integration.js' => 'JavaScript de integração',
            'components/professional-loading.php' => 'Componente de loading'
        ];

        foreach ($arquivos_obrigatorios as $arquivo => $descricao) {
            if (file_exists($arquivo)) {
                echo "<div class='success'>✅ <strong>{$arquivo}</strong> - {$descricao}</div>";
                $diagnostico[$arquivo] = 'OK';
            } else {
                echo "<div class='error'>❌ <strong>{$arquivo}</strong> - NÃO ENCONTRADO</div>";
                $diagnostico[$arquivo] = 'ERRO';
                $erros_criticos++;
            }
        }

        echo "</div>";

        // =========================================
        // 2. TESTAR INCLUDES
        // =========================================
        echo "<div class='section'>";
        echo "<h2>🔧 2. TESTANDO INCLUDES E CLASSES</h2>";

        try {
            if (file_exists('config/database.php')) {
                require_once 'config/database.php';
                echo "<div class='success'>✅ config/database.php carregado com sucesso</div>";

                // Testar conexão
                $connectionTest = testDatabaseConnection();

                if ($connectionTest['success']) {
                    echo "<div class='success'>✅ Conexão com banco: <strong>OK</strong></div>";
                    echo "<div class='info'>📄 Database: {$connectionTest['database']}<br>";
                    echo "🖥️ MySQL Version: {$connectionTest['server_version']}</div>";
                } else {
                    echo "<div class='error'>❌ Conexão com banco: <strong>ERRO</strong><br>";
                    echo "Erro: {$connectionTest['message']}</div>";
                    $erros_criticos++;
                }
            } else {
                echo "<div class='error'>❌ config/database.php não encontrado</div>";
                $erros_criticos++;
            }
        } catch (Exception $e) {
            echo "<div class='error'>❌ Erro ao carregar database.php: " . $e->getMessage() . "</div>";
            $erros_criticos++;
        }

        try {
            if (file_exists('classes/MemorialDescritivo.php')) {
                require_once 'classes/MemorialDescritivo.php';
                echo "<div class='success'>✅ classes/MemorialDescritivo.php carregado</div>";

                $memorial = new MemorialDescritivo();
                echo "<div class='success'>✅ Classe MemorialDescritivo instanciada</div>";

                // Testar template
                $template = $memorial->obterTemplate();
                if ($template) {
                    echo "<div class='success'>✅ Template encontrado: " . $template['nome_template'] . "</div>";
                    echo "<div class='info'>📋 Seções: " . implode(', ', $template['secoes_obrigatorias']) . "</div>";
                } else {
                    echo "<div class='warning'>⚠️ Template não encontrado no banco</div>";
                    $avisos++;
                }
            } else {
                echo "<div class='error'>❌ classes/MemorialDescritivo.php não encontrado</div>";
                $erros_criticos++;
            }
        } catch (Exception $e) {
            echo "<div class='error'>❌ Erro na classe MemorialDescritivo: " . $e->getMessage() . "</div>";
            $erros_criticos++;
        }

        echo "</div>";

        // =========================================
        // 3. ESTATÍSTICAS DO BANCO
        // =========================================
        if ($erros_criticos == 0) {
            echo "<div class='section'>";
            echo "<h2>📊 3. ESTATÍSTICAS DO BANCO DE DADOS</h2>";

            try {
                $stats = db()->getDatabaseStats();

                echo "<div class='info'>";
                echo "<strong>📋 Total de tabelas:</strong> " . ($stats['total_tables'] ?? 'N/A') . "<br>";
                echo "<strong>📄 Documentos ativos:</strong> " . ($stats['documentos_ativos'] ?? 0) . "<br>";

                if (isset($stats['por_tipo']) && !empty($stats['por_tipo'])) {
                    echo "<strong>📑 Documentos por tipo:</strong><br>";
                    foreach ($stats['por_tipo'] as $tipo) {
                        echo "&nbsp;&nbsp;• " . ucfirst(str_replace('_', ' ', $tipo['tipo_documento'])) . ": " . $tipo['total'] . "<br>";
                    }
                }

                if (isset($stats['ultimo_documento'])) {
                    echo "<strong>🕒 Último documento:</strong> " . $stats['ultimo_documento']['projeto_nome'] .
                        " (" . date('d/m/Y H:i', strtotime($stats['ultimo_documento']['created_at'])) . ")";
                }
                echo "</div>";
            } catch (Exception $e) {
                echo "<div class='error'>❌ Erro ao obter estatísticas: " . $e->getMessage() . "</div>";
                $avisos++;
            }

            echo "</div>";
        }

        // =========================================
        // 4. TESTE DE PROCESSAMENTO
        // =========================================
        if ($erros_criticos == 0) {
            echo "<div class='section'>";
            echo "<h2>🤖 4. TESTE DE PROCESSAMENTO</h2>";

            $dadosExemplo = [
                'projeto_nome' => 'Teste Diagnóstico - ' . date('H:i:s'),
                'cliente' => 'Vale S.A.',
                'localizacao' => 'Itabira, Minas Gerais',
                'categoria_projeto' => 'lavra',
                'tipo_mineracao' => 'ferro',
                'porte_projeto' => 'medio',
                'complexidade' => 'media',
                'area_hectares' => 150.75,
                'investimento_estimado' => 50000000.00,
                'duracao_meses' => 24
            ];

            echo "<div class='info'><strong>📝 Dados de teste:</strong><br>";
            echo "Projeto: {$dadosExemplo['projeto_nome']}<br>";
            echo "Cliente: {$dadosExemplo['cliente']}<br>";
            echo "Localização: {$dadosExemplo['localizacao']}</div>";

            try {
                // Testar busca de similares
                $criterios = [
                    'categoria_projeto' => $dadosExemplo['categoria_projeto'],
                    'tipo_mineracao' => $dadosExemplo['tipo_mineracao'],
                    'porte_projeto' => $dadosExemplo['porte_projeto'],
                    'complexidade' => $dadosExemplo['complexidade']
                ];

                $similares = $memorial->buscarDocumentosSimilares($criterios, 3);

                if ($similares['success']) {
                    echo "<div class='success'>✅ Busca de documentos similares: OK</div>";
                    echo "<div class='info'>🔍 Encontrados: {$similares['total']} documentos similares</div>";
                } else {
                    echo "<div class='warning'>⚠️ Busca de similares: " . $similares['error'] . "</div>";
                    $avisos++;
                }

                // Testar inserção (opcional)
                echo "<div class='info'>💾 <strong>Teste de inserção:</strong> Simulado (não executado para evitar dados desnecessários)</div>";
            } catch (Exception $e) {
                echo "<div class='error'>❌ Erro no teste de processamento: " . $e->getMessage() . "</div>";
                $erros_criticos++;
            }

            echo "</div>";
        }

        // =========================================
        // 5. INFORMAÇÕES DO SISTEMA
        // =========================================
        echo "<div class='section'>";
        echo "<h2>💻 5. INFORMAÇÕES DO SISTEMA</h2>";

        echo "<div class='info'>";
        echo "<strong>🐘 PHP Version:</strong> " . phpversion() . "<br>";
        echo "<strong>🌐 Server:</strong> " . ($_SERVER['SERVER_SOFTWARE'] ?? 'N/A') . "<br>";
        echo "<strong>📁 Document Root:</strong> " . ($_SERVER['DOCUMENT_ROOT'] ?? 'N/A') . "<br>";
        echo "<strong>🔗 Script Path:</strong> " . ($_SERVER['SCRIPT_NAME'] ?? 'N/A') . "<br>";
        echo "<strong>⏰ Timezone:</strong> " . date_default_timezone_get() . "<br>";
        echo "<strong>💾 Memory Limit:</strong> " . ini_get('memory_limit') . "<br>";
        echo "<strong>⏳ Max Execution Time:</strong> " . ini_get('max_execution_time') . "s";
        echo "</div>";

        // Verificar extensões
        echo "<h6 class='mt-3'>🔌 Extensões PHP:</h6>";
        $extensoes_necessarias = ['pdo', 'pdo_mysql', 'json', 'mbstring', 'openssl', 'curl'];
        $extensoes_ok = 0;

        echo "<div class='row'>";
        foreach ($extensoes_necessarias as $ext) {
            $loaded = extension_loaded($ext);
            $extensoes_ok += $loaded ? 1 : 0;
            $class = $loaded ? 'success' : 'error';
            $icon = $loaded ? '✅' : '❌';

            echo "<div class='col-md-6'>";
            echo "<div class='{$class}'>{$icon} <strong>{$ext}</strong></div>";
            echo "</div>";
        }
        echo "</div>";

        echo "</div>";

        // =========================================
        // 6. ESTRUTURA DE PASTAS
        // =========================================
        echo "<div class='section'>";
        echo "<h2>📁 6. ESTRUTURA DE PASTAS</h2>";

        $estrutura_esperada = [
            'config' => ['database.php'],
            'classes' => ['MemorialDescritivo.php'],
            'modals' => ['developer-modal.php', 'memorial-descritivo-modal.php'],
            'components' => ['professional-loading.php'],
            'js' => ['memorial-integration.js'],
            'logs' => [] // Pasta pode estar vazia
        ];

        foreach ($estrutura_esperada as $pasta => $arquivos_esperados) {
            echo "<h6>📂 {$pasta}/</h6>";

            if (is_dir($pasta)) {
                echo "<div class='success'>✅ Pasta existe</div>";

                $arquivos_existentes = array_diff(scandir($pasta), ['.', '..']);

                if (!empty($arquivos_esperados)) {
                    foreach ($arquivos_esperados as $arquivo) {
                        if (in_array($arquivo, $arquivos_existentes)) {
                            echo "<div class='success'>&nbsp;&nbsp;✅ {$arquivo}</div>";
                        } else {
                            echo "<div class='error'>&nbsp;&nbsp;❌ {$arquivo} (faltando)</div>";
                            $erros_criticos++;
                        }
                    }
                }

                // Mostrar outros arquivos encontrados
                $outros_arquivos = array_diff($arquivos_existentes, $arquivos_esperados);
                if (!empty($outros_arquivos)) {
                    echo "<div class='info'>&nbsp;&nbsp;📄 Outros: " . implode(', ', $outros_arquivos) . "</div>";
                }
            } else {
                echo "<div class='error'>❌ Pasta não existe</div>";
                if (!empty($arquivos_esperados)) {
                    $erros_criticos++;
                } else {
                    $avisos++;
                }
            }

            echo "<br>";
        }

        echo "</div>";

        // =========================================
        // 7. TESTE JSON
        // =========================================
        echo "<div class='section'>";
        echo "<h2>🔄 7. TESTE DE JSON</h2>";

        $teste_json = [
            'success' => true,
            'message' => 'Teste de JSON',
            'data' => $dadosExemplo,
            'timestamp' => date('Y-m-d H:i:s'),
            'caracteres_especiais' => 'Acentos: áéíóú, Cedilha: ç, Til: ã'
        ];

        $json_gerado = json_encode($teste_json, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        if ($json_gerado === false) {
            echo "<div class='error'>❌ Erro ao gerar JSON: " . json_last_error_msg() . "</div>";
            $erros_criticos++;
        } else {
            echo "<div class='success'>✅ JSON gerado com sucesso</div>";

            $json_decodificado = json_decode($json_gerado, true);
            if ($json_decodificado === null) {
                echo "<div class='error'>❌ Erro ao decodificar JSON: " . json_last_error_msg() . "</div>";
                $erros_criticos++;
            } else {
                echo "<div class='success'>✅ JSON decodificado com sucesso</div>";
                echo "<details class='mt-2'>";
                echo "<summary>📋 Ver JSON de exemplo</summary>";
                echo "<pre>" . htmlspecialchars($json_gerado) . "</pre>";
                echo "</details>";
            }
        }

        echo "</div>";

        // =========================================
        // 8. RESUMO FINAL
        // =========================================
        echo "<div class='section'>";
        echo "<h2>🎯 8. RESUMO FINAL</h2>";

        if ($erros_criticos == 0) {
            echo "<div class='alert alert-success' role='alert'>";
            echo "<h4 class='alert-heading'>🎉 SISTEMA FUNCIONANDO!</h4>";
            echo "<p><strong>✅ Todos os componentes essenciais estão funcionando</strong></p>";
            echo "<hr>";
            echo "<p class='mb-0'><strong>🚀 Próximos passos:</strong></p>";
            echo "<ul class='mb-0'>";
            echo "<li>Testar o backend: <a href='test_backend.html' target='_blank'>test_backend.html</a></li>";
            echo "<li>Usar o sistema: <a href='index.php' target='_blank'>index.php</a></li>";
            echo "<li>Se houver problemas, use: processar_memorial_simple.php</li>";
            echo "</ul>";
            echo "</div>";
        } else {
            echo "<div class='alert alert-danger' role='alert'>";
            echo "<h4 class='alert-heading'>❌ PROBLEMAS ENCONTRADOS</h4>";
            echo "<p><strong>Erros críticos: {$erros_criticos}</strong></p>";
            echo "<hr>";
            echo "<p class='mb-0'><strong>🔧 Ações necessárias:</strong></p>";
            echo "<ul class='mb-0'>";
            if (!file_exists('config/database.php')) {
                echo "<li>Criar o arquivo config/database.php</li>";
            }
            if (!file_exists('classes/MemorialDescritivo.php')) {
                echo "<li>Criar o arquivo classes/MemorialDescritivo.php</li>";
            }
            if (!file_exists('js/memorial-integration.js')) {
                echo "<li>Criar o arquivo js/memorial-integration.js</li>";
            }
            echo "<li>Verificar credenciais do banco de dados</li>";
            echo "<li>Executar o script SQL do banco minedocs</li>";
            echo "</ul>";
            echo "</div>";
        }

        if ($avisos > 0) {
            echo "<div class='alert alert-warning' role='alert'>";
            echo "<h6>⚠️ Avisos encontrados: {$avisos}</h6>";
            echo "<p class='mb-0'>O sistema pode funcionar, mas alguns recursos podem estar limitados.</p>";
            echo "</div>";
        }

        // Estatísticas do diagnóstico
        echo "<div class='row mt-4'>";
        echo "<div class='col-md-4'>";
        echo "<div class='card text-center'>";
        echo "<div class='card-body'>";
        echo "<h5 class='card-title text-danger'>{$erros_criticos}</h5>";
        echo "<p class='card-text'>Erros Críticos</p>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
        echo "<div class='col-md-4'>";
        echo "<div class='card text-center'>";
        echo "<div class='card-body'>";
        echo "<h5 class='card-title text-warning'>{$avisos}</h5>";
        echo "<p class='card-text'>Avisos</p>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
        echo "<div class='col-md-4'>";
        echo "<div class='card text-center'>";
        echo "<div class='card-body'>";
        echo "<h5 class='card-title text-success'>" . ($extensoes_ok) . "/" . count($extensoes_necessarias) . "</h5>";
        echo "<p class='card-text'>Extensões PHP</p>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
        echo "</div>";

        echo "</div>";
        ?>

        <div class="text-center mt-4 mb-4">
            <a href="index.php" class="btn btn-primary">
                <i class="bi bi-house"></i> Voltar ao Sistema
            </a>
            <a href="test_backend.html" class="btn btn-info">
                <i class="bi bi-play-circle"></i> Testar Backend
            </a>
            <button onclick="location.reload()" class="btn btn-secondary">
                <i class="bi bi-arrow-clockwise"></i> Executar Novamente
            </button>
        </div>

        <div class="text-center">
            <small class="text-muted">
                MineDocs Diagnostic Tool v1.0 |
                Tempo de execução: <?= number_format((microtime(true) - $_SERVER['REQUEST_TIME_FLOAT']) * 1000, 0) ?>ms
            </small>
        </div>
    </div>
</body>

</html>